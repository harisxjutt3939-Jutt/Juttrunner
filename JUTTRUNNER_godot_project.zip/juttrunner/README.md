# JUTTRUNNER - 3D Dungeon Runner (Godot 4.3, GDScript, Android)

Original dark-fantasy endless runner: 3 lanes, swipe / button controls, procedural dungeon,
Mana Crystals, 5 hunters with abilities, shop, missions, achievements, 5 dungeon themes.
Portrait orientation (best for lane runners), GL Compatibility renderer (works on low-end phones).
All models are procedural placeholders and all audio is synthesised at startup, so there are no binary assets.

## HONEST STATUS
* Written without access to the Godot engine. It has NOT been opened, run, exported or tested on a device.
* `python3 tools/validate_project.py` (static checks only) passes, but expect to fix a few small
  GDScript errors the first time you open it in Godot 4.3 - the Output panel names file and line.
* No APK has been built. Instructions below are untested.

## Controls
Swipe left/right = change lane, up = jump, down = slide (or on-screen buttons; Settings > Controls).
Ability button = hunter ability. Keyboard (desktop test): arrows/WASD, Space, E, Esc.

## 1. Open and test on a PC (easiest first check)
1. Install Godot 4.3 (standard build, not .NET) from godotengine.org.
2. Project Manager > Import > select `project.godot`. Let it import (builds the class cache).
3. Press F5. Window is portrait; mouse drag simulates swipes.
4. Check the Output panel for errors and fix/report them.

## 2. Where each command works
| Task | PC/Linux/cloud (x86_64) | Termux on the phone |
|---|---|---|
| Unzip, edit code, run `tools/validate_project.py` | yes | yes (`pkg install python unzip`) |
| Godot editor / export APK | yes | NOT supported (Godot Android tooling needs a desktop Linux/Win/Mac JDK + SDK) |
| Install a ready APK | `adb install` | yes (`termux_install.sh` or `adb`) |

So: **build the APK on a PC or GitHub Actions, install it from Termux/phone.**

## 3. Build debug APK on PC/Linux
1. Install JDK 17 and the Android command-line tools; set `ANDROID_SDK_ROOT`.
2. Install Godot 4.3 and export templates (Editor > Manage Export Templates), or the .tpz manually.
3. `bash tools/setup_android_env.sh` - creates debug keystore, installs SDK packages
   (platform-tools, build-tools 34.0.0, android-34, cmake 3.10.2.4988404, NDK 23.2.8568313 - versions per Godot 4.3 docs; check docs for other versions)
   and writes Godot editor settings.
4. `bash tools/export_android.sh` -> `build/JUTTRUNNER-debug.apk`.
   Or in the editor: Editor > Editor Settings > Export > Android (set SDK/JDK/keystore), Project > Export > Android Debug > Export Project.

## 4. Build without a PC: GitHub Actions (untested)
Push the project to GitHub, run workflow "Android Debug APK" (.github/workflows/android-debug.yml), download the artifact on your phone.

## 5. Install the APK
* Termux: `termux-setup-storage`, put the APK in Downloads, `bash tools/termux_install.sh ~/storage/downloads/JUTTRUNNER-debug.apk`
  (allow "Install unknown apps" for Termux).
* From a PC with USB debugging: `adb install -r build/JUTTRUNNER-debug.apk`.
* Termux wireless adb (Android 11+): `pkg install android-tools`, Developer options > Wireless debugging > pair,
  `adb pair IP:PORT CODE`, `adb connect IP:PORT`, `adb install -r JUTTRUNNER-debug.apk`.

## Project layout
```
project.godot, export_presets.cfg, icon.svg
scenes/   splash, main_menu, game, player, camera_rig, section, hud, ui/*_screen
scripts/
  autoload/ catalog.gd (all game data) save_data.gd (save/missions/shop logic) audio_manager.gd (procedural audio)
  game.gd (run controller) world.gd (endless generator + collisions) section.gd (dungeon modules)
  entity.gd + pool.gd (pooled obstacles/enemies/crystals/power-ups) player.gd hunter_model.gd hunter_preview.gd
  camera_rig.gd effects.gd assets.gd (shared meshes/materials) gfx.gd (quality presets)
  ui/ ui_kit.gd screen_base.gd hud.gd splash.gd main_menu.gd hunters/shop/dungeons/missions/settings screens
tools/    validate_project.py, setup_android_env.sh, export_android.sh, termux_install.sh
```

## Design notes
* Player stays at z=0; sections scroll towards the camera and are recycled (pooling, no allocation per frame).
* Hunters: Shadow (free, slows time), Blade (dash), Ice (freeze obstacles), Flame (damage immunity, 3 HP), Phantom (phase).
  Others unlock by crystals or by reaching a distance in one run.
* Power-ups: Magnet 10 s, Shield (1 hit or 12 s), Speed Burst 5 s (+50% speed, smash), Double Mana 12 s.
* Economy: crystals from pickups, missions, achievements, distance milestones. Currency never costs real money.
  Saved to `user://juttrunner_save.dat`; saved on every purchase, run end, and app pause/close.
* Quality (Low/Medium/High) changes lights, ambient particles, MSAA, render scale, section count.

## Replacing placeholders
* Models: replace `hunter_model.gd` / `entity.gd` builders with imported .glb scenes.
* Audio: assign real AudioStreams into `AudioFX.sounds["crystal"]` etc. (see `generate_all`).
* Tuning: all numbers live in `catalog.gd` and the constants at the top of `game.gd`.
