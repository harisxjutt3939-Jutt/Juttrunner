#!/usr/bin/env python3
"""Static sanity checks for the JUTTRUNNER Godot project (works in Termux: `pkg install python`).
This is NOT a GDScript compiler. It catches: missing res:// files, mixed indentation, unbalanced
brackets, `:=` inference on Variant-returning calls, and calls to members that do not exist on
the project's own scripts/autoloads. Always open the project in Godot for the real check."""
import os, re, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors, warns = [], []

def files(ext):
    for d, _, fs in os.walk(ROOT):
        if ".godot" in d or "/build" in d:
            continue
        for f in fs:
            if f.endswith(ext):
                yield os.path.join(d, f)

def rel(p): return os.path.relpath(p, ROOT)
def res_exists(r): return os.path.exists(os.path.join(ROOT, r[len("res://"):]))

# 1. project.godot paths
proj = open(os.path.join(ROOT, "project.godot")).read()
for m in re.finditer(r'"\*?(res://[^"]+)"', proj):
    if not res_exists(m.group(1)):
        errors.append(f"project.godot: missing {m.group(1)}")

# 2. scenes
for p in files(".tscn"):
    for m in re.finditer(r'path="(res://[^"]+)"', open(p).read()):
        if not res_exists(m.group(1)):
            errors.append(f"{rel(p)}: missing {m.group(1)}")

# 3. scripts
member_db, class_files = {}, {}
for p in files(".gd"):
    src = open(p).read()
    name = os.path.basename(p)[:-3]
    m = re.search(r"^class_name\s+(\w+)", src, re.M)
    key = m.group(1) if m else None
    members = set(re.findall(r"^\s*(?:static\s+)?func\s+(\w+)", src, re.M))
    members |= set(re.findall(r"^\s*(?:@onready\s+)?var\s+(\w+)", src, re.M))
    members |= set(re.findall(r"^\s*const\s+(\w+)", src, re.M))
    members |= set(re.findall(r"^\s*signal\s+(\w+)", src, re.M))
    member_db[p] = members
    if key: class_files[key] = p
    class_files.setdefault("@" + name, p)

autoloads = {"Catalog": "scripts/autoload/catalog.gd", "SaveData": "scripts/autoload/save_data.gd",
             "AudioFX": "scripts/autoload/audio_manager.gd"}
dyn = {"hud": "scripts/ui/hud.gd", "player": "scripts/player.gd", "world": "scripts/world.gd",
       "cam_rig": "scripts/camera_rig.gd", "fx": "scripts/effects.gd"}
targets = {k: os.path.join(ROOT, v) for k, v in autoloads.items()}
targets.update({k: class_files[k] for k in class_files if not k.startswith("@")})
CHECK_DYN = os.path.join(ROOT, "scripts/game.gd")

for p in files(".gd"):
    src = open(p).read()
    lines = src.split("\n")
    # indentation
    tabs = sum(1 for l in lines if l.startswith("\t"))
    spaces = sum(1 for l in lines if l.startswith("    "))
    if tabs and spaces:
        errors.append(f"{rel(p)}: mixed tab/space indentation")
    # res:// references
    for m in re.finditer(r'(?:load|preload)\("(res://[^"]+)"\)', src):
        if not res_exists(m.group(1)):
            errors.append(f"{rel(p)}: missing {m.group(1)}")
    # bracket balance (strip strings/comments)
    clean = re.sub(r'#[^\n]*', '', re.sub(r'"(?:\\.|[^"\\])*"', '""', src))
    for a, b in ("()", "[]", "{}"):
        if clean.count(a) != clean.count(b):
            errors.append(f"{rel(p)}: unbalanced {a}{b} ({clean.count(a)} vs {clean.count(b)})")
    # := on Variant-returning calls
    for i, l in enumerate(lines, 1):
        if re.search(r":=\s*(max|min|clamp|lerp|abs|sign|snapped|wrapf?)\(", l):
            errors.append(f"{rel(p)}:{i}: ':=' with Variant-returning call: {l.strip()}")
        if re.search(r":=\s*[\w.]+\[", l) or re.search(r":=\s*[\w.]+\.get\(", l):
            warns.append(f"{rel(p)}:{i}: ':=' on indexed/get value may not infer: {l.strip()}")
    # member access on known classes
    for cls, tp in targets.items():
        if not os.path.exists(tp) or tp == p: continue
        for m in re.finditer(r"\b" + cls + r"\.(\w+)", src):
            if m.group(1) not in member_db.get(tp, set()) and m.group(1) not in ("new",):
                errors.append(f"{rel(p)}: {cls}.{m.group(1)} not found in {rel(tp)}")
    if p == CHECK_DYN:
        for var, tp in dyn.items():
            tp = os.path.join(ROOT, tp)
            for m in re.finditer(r"\b" + var + r"\.(\w+)", src):
                if m.group(1) not in member_db[tp] and m.group(1) not in ("position", "stats", "hp", "max_hp", "alive", "invuln", "ability_invuln", "connect"):
                    errors.append(f"game.gd: {var}.{m.group(1)} not found in {rel(tp)}")

for w in warns: print("WARN ", w)
for e in errors: print("ERROR", e)
print(f"\n{len(errors)} error(s), {len(warns)} warning(s)")
sys.exit(1 if errors else 0)
