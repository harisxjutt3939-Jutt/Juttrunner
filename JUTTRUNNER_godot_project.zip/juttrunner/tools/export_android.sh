#!/usr/bin/env bash
# Run on a Linux PC / cloud VM with Godot 4.3 installed as `godot` (or set GODOT=/path/to/godot).
set -euo pipefail
cd "$(dirname "$0")/.."
GODOT="${GODOT:-godot}"
mkdir -p build
"$GODOT" --headless --path . --import || true      # builds the class_name cache + imports assets
"$GODOT" --headless --path . --export-debug "Android Debug" build/JUTTRUNNER-debug.apk
ls -lh build/JUTTRUNNER-debug.apk
