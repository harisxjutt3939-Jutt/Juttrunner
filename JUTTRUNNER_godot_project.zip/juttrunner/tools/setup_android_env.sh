#!/usr/bin/env bash
# Run on a Linux PC / cloud VM (x86_64) - NOT in Termux.
# Prepares Godot editor settings so `godot --headless --export-debug` can build an APK.
# Prerequisites: JDK 17, Android SDK (cmdline-tools) installed, Godot 4.3 + matching export templates.
set -euo pipefail
GODOT_VERSION="${GODOT_VERSION:-4.3}"
ANDROID_SDK="${ANDROID_SDK_ROOT:-$HOME/android-sdk}"
JAVA_HOME_DIR="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(which javac)")")")}"
KEYSTORE="$HOME/.android/debug.keystore"

mkdir -p "$HOME/.android" "$HOME/.config/godot"
if [ ! -f "$KEYSTORE" ]; then
  keytool -keyalg RSA -genkeypair -alias androiddebugkey -keypass android -keystore "$KEYSTORE" \
    -storepass android -dname "CN=Android Debug,O=Android,C=US" -validity 9999 -deststoretype pkcs12
fi

# SDK packages (versions are the ones documented for Godot 4.3; check docs.godotengine.org if you use another version)
yes | "$ANDROID_SDK/cmdline-tools/latest/bin/sdkmanager" --licenses >/dev/null || true
"$ANDROID_SDK/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "build-tools;34.0.0" "platforms;android-34" \
  "cmake;3.10.2.4988404" "ndk;23.2.8568313"

cat > "$HOME/.config/godot/editor_settings-${GODOT_VERSION}.tres" <<SETTINGS
[gd_resource type="EditorSettings" format=3]

[resource]
export/android/android_sdk_path = "$ANDROID_SDK"
export/android/java_sdk_path = "$JAVA_HOME_DIR"
export/android/debug_keystore = "$KEYSTORE"
export/android/debug_keystore_user = "androiddebugkey"
export/android/debug_keystore_pass = "android"
SETTINGS
echo "Editor settings written to ~/.config/godot/editor_settings-${GODOT_VERSION}.tres"
