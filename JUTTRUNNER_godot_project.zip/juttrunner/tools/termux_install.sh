#!/data/data/com.termux/files/usr/bin/bash
# Runs in Termux on the phone. Installs an APK you already built elsewhere.
# Usage: bash termux_install.sh /sdcard/Download/JUTTRUNNER-debug.apk
set -e
APK="${1:-$HOME/storage/downloads/JUTTRUNNER-debug.apk}"
[ -f "$APK" ] || { echo "APK not found: $APK  (run termux-setup-storage first)"; exit 1; }
cp "$APK" "$HOME/JUTTRUNNER-debug.apk"
echo "Opening Android package installer (allow 'Install unknown apps' for Termux when asked)..."
termux-open "$HOME/JUTTRUNNER-debug.apk"
