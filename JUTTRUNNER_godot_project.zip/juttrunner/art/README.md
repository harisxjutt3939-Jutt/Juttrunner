# JUTTRUNNER art slots

Drop PNG files here with EXACTLY these names. If a file exists the game shows it; if not, the built-in
placeholder is used. No code changes needed. Re-run the GitHub build after uploading.

| File | Used for | Suggested size |
|---|---|---|
| splash_bg.png | splash screen + (optionally) menu backdrop | 1080x1000, hero in upper part |
| menu_bg.png | main menu backdrop (dungeon corridor, dark) | 1080x1920 |
| hunters/shadow.png, blade.png, ice.png, flame.png, phantom.png | portraits in Hunters + Shop | 768x1024 |
| themes/catacombs.png, caverns.png, ruins.png, abyss.png, ember.png | dungeon cards | 512x512 |

The shadow/blade/ice/splash images included now are LOW-RESOLUTION crops of your concept sheet (upscaled).
Replace them with the original high-resolution images from your image tool for a sharp look.
Flame and Phantom have no portrait yet (3D placeholder is shown).
