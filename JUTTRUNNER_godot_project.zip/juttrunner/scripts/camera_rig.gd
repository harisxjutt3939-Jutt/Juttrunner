extends Node3D
## Third-person chase camera with lane follow, speed FOV and hit shake.

var _shake: float = 0.0
var _target_x: float = 0.0
@onready var cam: Camera3D = $Camera3D


func _ready() -> void:
	cam.keep_aspect = Camera3D.KEEP_WIDTH  # portrait: keep all 3 lanes visible
	cam.fov = 78.0
	cam.far = 150.0
	position = Vector3(0, 3.7, 5.6)
	look_at(Vector3(0, 1.2, -8.0))


func add_shake(amount: float) -> void:
	_shake = maxf(_shake, amount)


func follow(px: float, delta: float, speed_ratio: float) -> void:
	_target_x = lerpf(_target_x, px, clampf(delta * 6.0, 0.0, 1.0))
	var sx: float = 0.0
	var sy: float = 0.0
	if _shake > 0.01:
		sx = randf_range(-1.0, 1.0) * _shake * 0.25
		sy = randf_range(-1.0, 1.0) * _shake * 0.2
		_shake = lerpf(_shake, 0.0, clampf(delta * 7.0, 0.0, 1.0))
	position = Vector3(_target_x * 0.55 + sx, 3.7 + sy, 5.6)
	look_at(Vector3(_target_x * 0.3, 1.2, -8.0))
	cam.fov = lerpf(cam.fov, 78.0 + speed_ratio * 8.0, clampf(delta * 3.0, 0.0, 1.0))
