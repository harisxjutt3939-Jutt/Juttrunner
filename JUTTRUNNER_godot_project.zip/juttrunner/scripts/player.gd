extends Node3D
## Hunter controller: lane switching, jump, slide, damage state, trail and aura.
## The player stays at z = 0; the world scrolls towards the camera.

const LANE_X: Array = [-2.2, 0.0, 2.2]
const GRAVITY := 32.0

var model: HunterModel
var stats: Dictionary = {}
var lane: int = 1
var y_vel: float = 0.0
var on_ground: bool = true
var slide_time: float = 0.0
var hp: int = 2
var max_hp: int = 2
var invuln: float = 0.0
var ability_invuln: bool = false
var alive: bool = true

var _trail: CPUParticles3D
var _aura: MeshInstance3D
var _aura_mat: StandardMaterial3D
var _hit_time: float = 0.0
var _queued_slide: bool = false


func setup(hunter_id: String, skin_id: String, trail_id: String, quality: int) -> void:
	stats = Catalog.HUNTERS[hunter_id]
	hp = int(stats["hp"])
	max_hp = hp
	model = HunterModel.new()
	add_child(model)
	model.build(hunter_id, skin_id)
	model.state = "run"

	var lamp := OmniLight3D.new()
	lamp.position = Vector3(0, 2.4, 1.2)
	lamp.light_color = Color("#9fb8ff")
	lamp.light_energy = 1.0
	lamp.omni_range = 10.0
	add_child(lamp)

	_aura_mat = StandardMaterial3D.new()
	_aura_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_aura_mat.emission_enabled = true
	_aura_mat.emission_energy_multiplier = 1.5
	_aura = MeshInstance3D.new()
	_aura.mesh = Assets.sphere(1.15, 12)
	_aura.material_override = _aura_mat
	_aura.position = Vector3(0, 1.0, 0)
	_aura.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	_aura.visible = false
	add_child(_aura)

	if trail_id != "none" and Catalog.TRAILS.has(trail_id):
		var tc: Color = Catalog.TRAILS[trail_id]["color"]
		_trail = CPUParticles3D.new()
		_trail.amount = maxi(int(22.0 * Gfx.particle_scale(quality)), 6)
		_trail.lifetime = 0.7
		_trail.local_coords = false
		_trail.direction = Vector3(0, 0.1, 1)
		_trail.spread = 10.0
		_trail.gravity = Vector3.ZERO
		_trail.initial_velocity_min = 8.0
		_trail.initial_velocity_max = 8.0
		_trail.scale_amount_min = 0.6
		_trail.scale_amount_max = 1.2
		_trail.mesh = Assets.sphere(0.09, 6)
		_trail.material_override = Assets.colored(tc, 2.5)
		_trail.position = Vector3(0, 0.25, 0.3)
		add_child(_trail)


func set_aura(color: Color, on: bool) -> void:
	_aura.visible = on
	if on:
		_aura_mat.albedo_color = Color(color.r, color.g, color.b, 0.28)
		_aura_mat.emission = color


# ------------------------------------------------------------------ actions
func change_lane(dir: int) -> bool:
	if not alive:
		return false
	var nl: int = clampi(lane + dir, 0, 2)
	if nl == lane:
		return false
	lane = nl
	return true


func jump() -> bool:
	if not alive or not on_ground:
		return false
	slide_time = 0.0
	y_vel = float(stats["jump"])
	on_ground = false
	position.y = 0.001
	return true


func slide() -> bool:
	if not alive:
		return false
	if not on_ground:
		y_vel = -22.0
		_queued_slide = true
		return true
	slide_time = 0.75
	return true


func body_height() -> float:
	return 0.85 if slide_time > 0.0 else 1.8


func is_invulnerable() -> bool:
	return invuln > 0.0 or ability_invuln


func take_hit() -> void:
	hp -= 1
	invuln = 1.6
	_hit_time = 0.45
	if hp <= 0:
		die()


func die() -> void:
	alive = false
	model.visible = true
	model.state = "dead"
	if _trail != null:
		_trail.emitting = false
	_aura.visible = false


# ------------------------------------------------------------------ per-frame
func tick(delta: float, world_speed: float) -> void:
	if not alive:
		return
	var tx: float = LANE_X[lane]
	position.x = move_toward(position.x, tx, float(stats["lane_speed"]) * delta)
	var dx: float = tx - position.x
	model.rotation.z = lerpf(model.rotation.z, -dx * 0.12, clampf(delta * 12.0, 0.0, 1.0))
	model.rotation.y = lerpf(model.rotation.y, -dx * 0.15, clampf(delta * 12.0, 0.0, 1.0))

	if not on_ground:
		y_vel -= GRAVITY * delta
		position.y += y_vel * delta
		if position.y <= 0.0:
			position.y = 0.0
			y_vel = 0.0
			on_ground = true
			if _queued_slide:
				_queued_slide = false
				slide_time = 0.75
	if slide_time > 0.0:
		slide_time -= delta

	if _hit_time > 0.0:
		_hit_time -= delta
		model.state = "hit"
	elif not on_ground:
		model.state = "jump"
	elif slide_time > 0.0:
		model.state = "slide"
	else:
		model.state = "run"
	model.run_rate = clampf(world_speed / 14.0, 0.7, 1.6)

	if invuln > 0.0:
		invuln -= delta
		model.visible = int(invuln * 14.0) % 2 == 0
	else:
		model.visible = true

	if _trail != null:
		_trail.initial_velocity_min = world_speed
		_trail.initial_velocity_max = world_speed
	if _aura.visible:
		_aura.scale = Vector3.ONE * (1.0 + sin(float(Time.get_ticks_msec()) * 0.008) * 0.05)
