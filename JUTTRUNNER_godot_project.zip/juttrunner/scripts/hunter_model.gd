class_name HunterModel
extends Node3D
## Procedural low-poly hunter built from primitives, with code-driven animation.
## States: "idle", "run", "jump", "slide", "hit", "dead". Front of the character faces -Z.

const SKIN_TONE := Color("#e8c4a0")

var state: String = "run"
var run_rate: float = 1.0

var rig: Node3D
var torso: Node3D
var head: Node3D
var arm_l: Node3D
var arm_r: Node3D
var leg_l: Node3D
var leg_r: Node3D
var _t: float = 0.0


func build(hunter_id: String, skin_id: String) -> void:
	for c in get_children():
		remove_child(c)
		c.queue_free()
	var h: Dictionary = Catalog.HUNTERS[hunter_id]
	var sk: Dictionary = Catalog.SKINS[skin_id]
	var outfit: Color = sk["color"]
	var accent: Color = sk["accent"]
	var hair: Color = h["hair"]
	var m_outfit: StandardMaterial3D = Assets.colored(outfit)
	var m_trim: StandardMaterial3D = Assets.colored(outfit.lightened(0.3))
	var m_dark: StandardMaterial3D = Assets.colored(outfit.darkened(0.45))
	var m_accent: StandardMaterial3D = Assets.colored(accent, 1.6)
	var m_skin: StandardMaterial3D = Assets.colored(SKIN_TONE)
	var m_hair: StandardMaterial3D = Assets.colored(hair)
	var face_mat: StandardMaterial3D = m_skin
	if hunter_id == "phantom":
		face_mat = m_dark

	rig = Node3D.new()
	add_child(rig)

	torso = _pivot(rig, Vector3(0, 0.9, 0))
	Assets.add(torso, Assets.box(Vector3(0.56, 0.7, 0.32)), m_outfit, Vector3(0, 0.35, 0))
	Assets.add(torso, Assets.box(Vector3(0.14, 0.7, 0.34)), m_accent, Vector3(0, 0.35, 0))
	Assets.add(torso, Assets.box(Vector3(0.6, 0.1, 0.36)), m_dark, Vector3(0, 0.03, 0))

	head = _pivot(torso, Vector3(0, 0.95, 0))
	Assets.add(head, Assets.sphere(0.22, 10), face_mat, Vector3.ZERO)
	Assets.add(head, Assets.box(Vector3(0.1, 0.05, 0.04)), m_accent, Vector3(-0.08, 0.02, -0.2))
	Assets.add(head, Assets.box(Vector3(0.1, 0.05, 0.04)), m_accent, Vector3(0.08, 0.02, -0.2))

	arm_l = _pivot(torso, Vector3(-0.38, 0.62, 0))
	arm_r = _pivot(torso, Vector3(0.38, 0.62, 0))
	for arm in [arm_l, arm_r]:
		Assets.add(arm, Assets.box(Vector3(0.15, 0.62, 0.16)), m_outfit, Vector3(0, -0.28, 0))
		Assets.add(arm, Assets.sphere(0.09, 6), m_skin, Vector3(0, -0.62, 0))

	leg_l = _pivot(rig, Vector3(-0.15, 0.9, 0))
	leg_r = _pivot(rig, Vector3(0.15, 0.9, 0))
	for leg in [leg_l, leg_r]:
		Assets.add(leg, Assets.box(Vector3(0.2, 0.8, 0.22)), m_dark, Vector3(0, -0.4, 0))
		Assets.add(leg, Assets.box(Vector3(0.22, 0.16, 0.3)), m_trim, Vector3(0, -0.74, -0.03))

	match hunter_id:
		"shadow":
			Assets.add(head, Assets.box(Vector3(0.46, 0.14, 0.46)), m_hair, Vector3(0, 0.14, 0.02))
			Assets.add(head, Assets.box(Vector3(0.4, 0.3, 0.12)), m_hair, Vector3(0, -0.02, 0.2))
			for i in 4:
				Assets.add(head, Assets.cylinder(0.0, 0.1, 0.28, 5), m_hair, Vector3(-0.15 + i * 0.1, 0.3, 0.0), Vector3(0, 0, (i - 1.5) * -12.0))
			Assets.add(torso, Assets.box(Vector3(0.34, 0.1, 0.34)), m_accent, Vector3(0, 0.7, 0))
			Assets.add(torso, Assets.box(Vector3(0.28, 0.1, 0.9)), m_accent, Vector3(0, 0.6, 0.6), Vector3(10, 0, 0))
		"blade":
			Assets.add(head, Assets.box(Vector3(0.46, 0.14, 0.46)), m_hair, Vector3(0, 0.14, 0.02))
			for i in 4:
				Assets.add(head, Assets.cylinder(0.0, 0.1, 0.3, 5), m_hair, Vector3(-0.15 + i * 0.1, 0.3, 0.0), Vector3(0, 0, (i - 1.5) * -14.0))
			Assets.add(head, Assets.box(Vector3(0.47, 0.07, 0.47)), m_accent, Vector3(0, 0.06, 0.0))
			var sword: Node3D = _pivot(torso, Vector3(0, 0.4, 0.25))
			sword.rotation_degrees = Vector3(0, 0, 35)
			Assets.add(sword, Assets.box(Vector3(0.09, 1.3, 0.03)), Assets.colored(Color("#c9d4ee"), 0.4), Vector3(0, 0.1, 0))
			Assets.add(sword, Assets.box(Vector3(0.3, 0.05, 0.07)), m_accent, Vector3(0, 0.78, 0))
			Assets.add(sword, Assets.box(Vector3(0.06, 0.25, 0.06)), m_dark, Vector3(0, 0.95, 0))
		"ice":
			Assets.add(head, Assets.box(Vector3(0.46, 0.12, 0.46)), m_hair, Vector3(0, 0.14, 0.02))
			Assets.add(head, Assets.box(Vector3(0.4, 0.34, 0.12)), m_hair, Vector3(0, -0.04, 0.2))
			var ice: StandardMaterial3D = Assets.colored(Color("#bfefff"), 1.2)
			for i in 5:
				var a: float = float(i) / 5.0 * TAU
				Assets.add(head, Assets.cylinder(0.0, 0.07, 0.3, 5), ice, Vector3(cos(a) * 0.15, 0.3, sin(a) * 0.15))
			for sx in [-1.0, 1.0]:
				Assets.add(torso, Assets.cylinder(0.0, 0.1, 0.45, 5), ice, Vector3(sx * 0.4, 0.85, 0), Vector3(0, 0, sx * -30.0))
			Assets.add(torso, Assets.cylinder(0.0, 0.12, 0.7, 5), ice, Vector3(0, 0.55, 0.24), Vector3(20, 0, 0))
		"flame":
			var f1: StandardMaterial3D = Assets.colored(Color("#ff6a1a"), 2.0)
			var f2: StandardMaterial3D = Assets.colored(Color("#ffd24a"), 2.0)
			Assets.add(head, Assets.box(Vector3(0.44, 0.1, 0.44)), m_hair, Vector3(0, 0.15, 0.02))
			for i in 5:
				var mat: StandardMaterial3D = f1 if i % 2 == 0 else f2
				Assets.add(head, Assets.cylinder(0.0, 0.1, 0.34 + (i % 3) * 0.1, 5), mat, Vector3(-0.16 + i * 0.08, 0.3, 0.0), Vector3(0, 0, (i - 2) * -10.0))
			for sx in [-1.0, 1.0]:
				Assets.add(torso, Assets.sphere(0.13, 6), f1, Vector3(sx * 0.4, 0.7, 0))
			Assets.add(torso, Assets.box(Vector3(0.5, 0.7, 0.04)), m_accent, Vector3(0, 0.2, 0.22), Vector3(8, 0, 0))
		"phantom":
			Assets.add(head, Assets.sphere(0.27, 10), m_outfit, Vector3(0, 0.02, 0.04))
			Assets.add(head, Assets.cylinder(0.0, 0.2, 0.3, 6), m_outfit, Vector3(0, 0.3, 0.06))
			Assets.add(torso, Assets.box(Vector3(0.7, 1.2, 0.05)), m_outfit, Vector3(0, 0.15, 0.24), Vector3(-8, 0, 0))
			Assets.add(torso, Assets.box(Vector3(0.7, 0.04, 0.07)), m_accent, Vector3(0, -0.44, 0.34), Vector3(-8, 0, 0))
			for sx in [-1.0, 1.0]:
				Assets.add(arm_l if sx < 0.0 else arm_r, Assets.sphere(0.1, 6), m_accent, Vector3(0, -0.7, 0))


func _pivot(parent: Node3D, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	parent.add_child(n)
	return n


func _process(delta: float) -> void:
	if rig == null:
		return
	_t += delta
	var k: float = clampf(delta * 16.0, 0.0, 1.0)
	var al: float = 0.0
	var ar: float = 0.0
	var ll: float = 0.0
	var lr: float = 0.0
	var tx: float = 0.0
	var ry: float = 0.0
	var rx: float = 0.0
	var shake: float = 0.0
	match state:
		"run":
			var s: float = sin(_t * 11.0 * run_rate)
			al = s
			ar = -s
			ll = -s
			lr = s
			tx = -0.14
			ry = absf(s) * 0.07
		"idle":
			var b: float = sin(_t * 2.0)
			al = 0.05 + b * 0.04
			ar = 0.05 - b * 0.04
			ry = b * 0.012
		"jump":
			al = -2.4
			ar = -2.4
			ll = 0.9
			lr = -0.5
			tx = -0.1
		"slide":
			al = 1.4
			ar = 1.4
			ll = 1.35
			lr = 1.35
			tx = 1.0
			ry = -0.55
		"hit":
			al = -0.8
			ar = 0.8
			tx = 0.45
			shake = sin(_t * 40.0) * 0.08
		"dead":
			tx = 0.9
			rx = 1.4
			ry = -0.1
	arm_l.rotation.x = lerpf(arm_l.rotation.x, al, k)
	arm_r.rotation.x = lerpf(arm_r.rotation.x, ar, k)
	leg_l.rotation.x = lerpf(leg_l.rotation.x, ll, k)
	leg_r.rotation.x = lerpf(leg_r.rotation.x, lr, k)
	torso.rotation.x = lerpf(torso.rotation.x, tx, k)
	rig.position.y = lerpf(rig.position.y, ry, k)
	rig.rotation.x = lerpf(rig.rotation.x, rx, k)
	rig.position.x = shake
