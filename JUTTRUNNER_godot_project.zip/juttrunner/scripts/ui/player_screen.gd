extends ScreenBase
## Player data: level, collection progress and lifetime stats. Progress saves automatically.


func _init() -> void:
	title_text = "PLAYER DATA"


func _populate() -> void:
	var d: Dictionary = SaveData.data
	var xp: float = float(d["total_distance"]) + float(d["total_crystals"]) * 5.0
	var level: int = int(floor(sqrt(xp / 200.0))) + 1
	var lo: float = pow(float(level - 1), 2.0) * 200.0
	var hi: float = pow(float(level), 2.0) * 200.0
	var card: PanelContainer = UIKit.make_panel(UIKit.C_PANEL, UIKit.C_BLUE)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	card.add_child(vb)
	vb.add_child(UIKit.make_label("HUNTER  -  Level %d" % level, 34, UIKit.C_CYAN))
	vb.add_child(UIKit.make_bar(xp - lo, hi - lo, UIKit.C_BLUE))
	vb.add_child(UIKit.make_label("%d / %d XP  (distance + crystals)" % [int(xp), int(hi)], 22, UIKit.C_DIM))
	body.add_child(card)

	var skins_owned: int = (d["owned_skins"] as Array).size()
	var tiles: Array = [
		["Characters", "%d/%d" % [(d["owned_hunters"] as Array).size(), Catalog.HUNTER_ORDER.size()]],
		["Skins", "%d/%d" % [skins_owned, Catalog.HUNTER_ORDER.size() * 2]],
		["Trails", "%d/%d" % [(d["owned_trails"] as Array).size() - 1, Catalog.TRAIL_ORDER.size() - 1]],
		["Dungeons", "%d/%d" % [(d["owned_themes"] as Array).size(), Catalog.THEME_ORDER.size()]],
	]
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	for t in tiles:
		var p: PanelContainer = UIKit.make_panel(UIKit.C_PANEL2, UIKit.C_PURPLE)
		var tv := VBoxContainer.new()
		tv.add_child(UIKit.make_label(t[1], 40, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER))
		tv.add_child(UIKit.make_label(t[0], 24, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_CENTER))
		p.add_child(tv)
		grid.add_child(p)
	body.add_child(grid)

	var rows: Array = [
		["Best score", str(d["best_score"])],
		["Best distance", "%d m" % int(d["best_distance"])],
		["Runs finished", str(d["runs"])],
		["Total crystals collected", str(d["total_crystals"])],
		["Total distance", "%d m" % int(d["total_distance"])],
		["Longest run", "%d:%02d" % [floori(float(d["best_time"]) / 60.0), int(d["best_time"]) % 60]],
	]
	for r in rows:
		var rp: PanelContainer = UIKit.make_panel(UIKit.C_PANEL, Color("#14305a"))
		var hb := HBoxContainer.new()
		var l: Label = UIKit.make_label(r[0], 26, UIKit.C_DIM)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(l)
		hb.add_child(UIKit.make_label(r[1], 28, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_RIGHT))
		rp.add_child(hb)
		body.add_child(rp)
	body.add_child(UIKit.make_label("Progress is saved automatically.", 24, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_CENTER))
