extends ScreenBase
## Settings: sound, music, graphics quality, controls, vibration, reset.

const QUALITY: Array = ["Low", "Medium", "High"]
const CONTROLS: Array = ["Swipe", "Buttons", "Both"]


func _init() -> void:
	title_text = "SETTINGS"


func _slider(label: String, key: String) -> void:
	body.add_child(UIKit.make_label(label, 28, UIKit.C_SILVER))
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = float(SaveData.get_setting(key))
	s.custom_minimum_size = Vector2(0, 60)
	s.value_changed.connect(func(v: float) -> void:
		SaveData.data["settings"][key] = v
		AudioFX.apply_settings())
	s.drag_ended.connect(func(_changed: bool) -> void:
		SaveData.save_game()
		AudioFX.play("ui"))
	body.add_child(s)


func _choice(label: String, key: String, names: Array) -> void:
	body.add_child(UIKit.make_label(label, 28, UIKit.C_SILVER))
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var cur: int = int(SaveData.get_setting(key))
	for i in names.size():
		var b: Button = UIKit.make_button(str(names[i]), Vector2(0, 76), UIKit.C_PURPLE if i == cur else UIKit.C_DIM, 26)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var v: int = i
		b.pressed.connect(func() -> void:
			SaveData.set_setting(key, v)
			if key == "quality":
				Gfx.apply(get_viewport(), v)
			refresh())
		row.add_child(b)
	body.add_child(row)


func _populate() -> void:
	_slider("Sound effects", "sound")
	_slider("Music", "music")
	_choice("Graphics quality", "quality", QUALITY)
	body.add_child(UIKit.make_label("Low: fewer lights, no ambient particles, lower resolution. Best for old phones.", 20, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	_choice("Controls", "controls", CONTROLS)
	var vib: bool = bool(SaveData.get_setting("vibration"))
	var vb: Button = UIKit.make_button("Vibration: ON" if vib else "Vibration: OFF", Vector2(0, 76), UIKit.C_GREEN if vib else UIKit.C_DIM, 26)
	vb.pressed.connect(func() -> void:
		SaveData.set_setting("vibration", not vib)
		refresh())
	body.add_child(vb)
	var rb: Button = UIKit.make_button("RESET ALL PROGRESS", Vector2(0, 76), UIKit.C_RED, 24)
	rb.pressed.connect(func() -> void:
		UIKit.confirm(self, "Erase ALL progress, crystals and unlocks?", func() -> void:
			SaveData.reset_all()
			AudioFX.apply_settings()
			refresh(), "ERASE"))
	body.add_child(rb)
