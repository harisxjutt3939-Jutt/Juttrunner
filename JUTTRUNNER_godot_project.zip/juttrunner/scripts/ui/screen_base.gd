class_name ScreenBase
extends Control
## Shared layout for full-screen menus: header (back, title, balance), optional top area, scrolling body.

signal closed

var title_text: String = "SCREEN"
var body: VBoxContainer
var top_area: VBoxContainer
var scroll: ScrollContainer
var _balance: Label


func _ready() -> void:
	UIKit.fill(self)
	add_child(UIKit.make_bg())
	var margin := MarginContainer.new()
	UIKit.fill(margin)
	margin.add_theme_constant_override("margin_left", 24)
	margin.add_theme_constant_override("margin_right", 24)
	margin.add_theme_constant_override("margin_top", 28)
	margin.add_theme_constant_override("margin_bottom", 24)
	add_child(margin)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	margin.add_child(vb)

	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 12)
	vb.add_child(hb)
	var back: Button = UIKit.make_button("BACK", Vector2(150, 80), UIKit.C_PURPLE, 26)
	back.pressed.connect(close)
	hb.add_child(back)
	var t: Label = UIKit.make_label(title_text, 42, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_CENTER)
	t.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hb.add_child(t)
	hb.add_child(IconDraw.new("crystal", UIKit.C_BLUE, Vector2(34, 34)))
	_balance = UIKit.make_label("0", 30, UIKit.C_SILVER)
	hb.add_child(_balance)

	top_area = VBoxContainer.new()
	top_area.add_theme_constant_override("separation", 10)
	vb.add_child(top_area)
	scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	vb.add_child(scroll)
	body = VBoxContainer.new()
	body.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 12)
	scroll.add_child(body)

	SaveData.crystals_changed.connect(_on_balance)
	_on_balance(SaveData.crystals())
	_populate()


func _populate() -> void:
	pass


func refresh() -> void:
	for c in body.get_children():
		c.queue_free()
	_populate()


func _on_balance(v: int) -> void:
	_balance.text = str(v)


func close() -> void:
	closed.emit()
	queue_free()


func tab_buttons(names: Array, current: int, on_pick: Callable) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	for i in names.size():
		var b: Button = UIKit.make_button(str(names[i]), Vector2(0, 70), UIKit.C_PURPLE if i == current else UIKit.C_DIM, 22)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.pressed.connect(on_pick.bind(i))
		row.add_child(b)
	return row
