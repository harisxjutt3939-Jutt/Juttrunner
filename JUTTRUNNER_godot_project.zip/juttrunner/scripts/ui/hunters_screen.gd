extends ScreenBase
## Character selection: preview, stats, ability, select / buy, skins.

var _viewing: String = "shadow"
var _preview: HunterPreview
var _skin_view: String = ""


func _init() -> void:
	title_text = "HUNTERS"


func _populate() -> void:
	if _preview == null:
		_viewing = SaveData.data["hunter"]
		_preview = HunterPreview.new()
		_preview.custom_minimum_size = Vector2(0, 360)
		top_area.add_child(_preview)
		var hs := ScrollContainer.new()
		hs.custom_minimum_size = Vector2(0, 92)
		hs.vertical_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
		top_area.add_child(hs)
		var row := HBoxContainer.new()
		row.add_theme_constant_override("separation", 8)
		hs.add_child(row)
		for id in Catalog.HUNTER_ORDER:
			var b: Button = UIKit.make_button(str(Catalog.HUNTERS[id]["name"]).split(" ")[0], Vector2(150, 80), UIKit.C_PURPLE, 24)
			var hid: String = id
			b.pressed.connect(func() -> void:
				_viewing = hid
				_skin_view = ""
				refresh())
			row.add_child(b)
	var hd: Dictionary = Catalog.HUNTERS[_viewing]
	var skin: String = _skin_view if _skin_view != "" else SaveData.get_skin(_viewing)
	_preview.show_hunter(_viewing, skin)

	body.add_child(UIKit.make_label("%s - %s" % [hd["name"], hd["title"]], 34, UIKit.C_SILVER))
	body.add_child(UIKit.make_label(str(hd["desc"]), 24, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	var st: Dictionary = hd["stats"]
	for key in ["speed", "agility", "health"]:
		var hb := HBoxContainer.new()
		var l: Label = UIKit.make_label(str(key).capitalize(), 24, UIKit.C_SILVER)
		l.custom_minimum_size.x = 150.0
		hb.add_child(l)
		hb.add_child(UIKit.make_bar(float(st[key]), 5.0, UIKit.C_BLUE))
		body.add_child(hb)
	body.add_child(UIKit.make_label("%s (cooldown %d s)" % [hd["ability_name"], int(hd["ability_cd"])], 28, UIKit.C_PURPLE))
	body.add_child(UIKit.make_label(str(hd["ability_desc"]), 22, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))

	var owned: bool = SaveData.owns("hunters", _viewing)
	var main_btn: Button
	if owned:
		var selected: bool = SaveData.data["hunter"] == _viewing
		main_btn = UIKit.make_button("SELECTED" if selected else "SELECT", Vector2(0, 90), UIKit.C_GREEN if selected else UIKit.C_BLUE, 32)
		main_btn.disabled = selected
		main_btn.pressed.connect(func() -> void:
			SaveData.equip("hunters", _viewing)
			refresh())
	else:
		var price: int = int(hd["price"])
		main_btn = UIKit.make_button("BUY  %d MC" % price, Vector2(0, 90), UIKit.C_GOLD, 32)
		main_btn.pressed.connect(func() -> void: _try_buy("hunters", _viewing, price, str(hd["name"])))
		body.add_child(UIKit.make_label("Or unlock free by reaching %d m in one run (best: %d m)." % [hd["unlock_distance"], SaveData.data["best_distance"]], 22, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	body.add_child(main_btn)

	body.add_child(UIKit.make_label("Outfits", 30, UIKit.C_SILVER))
	var skins := HBoxContainer.new()
	skins.add_theme_constant_override("separation", 8)
	body.add_child(skins)
	for suffix in ["default", "royal", "void"]:
		var sid: String = _viewing + "_" + suffix
		var sd: Dictionary = Catalog.SKINS[sid]
		var has: bool = SaveData.owns("skins", sid)
		var txt: String = str(sd["name"])
		if not has:
			txt += "\n%d MC" % int(sd["price"])
		elif SaveData.get_skin(_viewing) == sid:
			txt += "\n(equipped)"
		var sb: Button = UIKit.make_button(txt, Vector2(0, 100), UIKit.C_PURPLE if has else UIKit.C_GOLD, 22)
		sb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		sb.pressed.connect(func() -> void:
			_skin_view = sid
			if has:
				if owned:
					SaveData.equip("skins", sid)
					_skin_view = ""
				refresh()
			elif not owned:
				UIKit.message(self, "Unlock this hunter first.")
			else:
				_try_buy("skins", sid, int(sd["price"]), str(sd["name"])))
		skins.add_child(sb)


func _try_buy(kind: String, id: String, price: int, label: String) -> void:
	if SaveData.crystals() < price:
		AudioFX.play("error")
		UIKit.message(self, "Not enough Mana Crystals!\nYou need %d more." % (price - SaveData.crystals()))
		return
	UIKit.confirm(self, "Buy %s for %d Mana Crystals?" % [label, price], func() -> void:
		if SaveData.buy(kind, id, price) == SaveData.BUY_OK:
			AudioFX.play("buy")
			if kind == "skins":
				SaveData.equip("skins", id)
				_skin_view = ""
		refresh())
