extends ScreenBase
## Dungeon theme selection / unlocking.


func _init() -> void:
	title_text = "DUNGEONS"


func _populate() -> void:
	body.add_child(UIKit.make_label("Best run: %d m. Themes unlock for free at their distance, or buy them with crystals." % int(SaveData.data["best_distance"]), 22, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	for id in Catalog.THEME_ORDER:
		var td: Dictionary = Catalog.THEMES[id]
		var owned: bool = SaveData.owns("themes", id)
		var selected: bool = SaveData.data["theme"] == id
		var vb := VBoxContainer.new()
		var sw := HBoxContainer.new()
		for key in ["wall", "glow", "fog"]:
			var cr := ColorRect.new()
			cr.color = td[key]
			cr.custom_minimum_size = Vector2(46, 24)
			sw.add_child(cr)
		vb.add_child(sw)
		var btn: Button
		var tid: String = id
		if owned:
			btn = UIKit.make_button("SELECTED" if selected else "SELECT", Vector2(170, 64), UIKit.C_GREEN if selected else UIKit.C_BLUE, 22)
			btn.disabled = selected
			btn.pressed.connect(func() -> void:
				SaveData.equip("themes", tid)
				refresh())
		else:
			var price: int = int(td["price"])
			btn = UIKit.make_button("%d MC" % price, Vector2(170, 64), UIKit.C_GOLD, 24)
			btn.pressed.connect(func() -> void: _try_buy(tid, price, str(td["name"])))
		vb.add_child(btn)
		var extra: String = "" if owned else " Unlocks free at %d m." % int(td["unlock_distance"])
		body.add_child(UIKit.item_row(str(td["name"]), str(td["desc"]) + extra, vb, UIKit.C_BLUE, Art.tex("res://art/themes/" + id + ".png")))


func _try_buy(id: String, price: int, label: String) -> void:
	if SaveData.crystals() < price:
		AudioFX.play("error")
		UIKit.message(self, "Not enough Mana Crystals!\nYou need %d more." % (price - SaveData.crystals()))
		return
	UIKit.confirm(self, "Unlock %s for %d Mana Crystals?" % [label, price], func() -> void:
		if SaveData.buy("themes", id, price) == SaveData.BUY_OK:
			AudioFX.play("buy")
			SaveData.equip("themes", id)
		refresh())
