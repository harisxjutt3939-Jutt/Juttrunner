class_name IconDraw
extends Control
## Tiny vector icons drawn in code (no font glyph or texture dependencies).

var kind: String = "crystal"
var color: Color = Color("#4ac8ff")


func _init(k: String = "crystal", c: Color = Color("#4ac8ff"), min_size: Vector2 = Vector2(32, 32)) -> void:
	kind = k
	color = c
	custom_minimum_size = min_size
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	resized.connect(queue_redraw)


func _draw() -> void:
	var s: Vector2 = size
	var cx: float = s.x * 0.5
	var cy: float = s.y * 0.5
	match kind:
		"crystal":
			var pts := PackedVector2Array([Vector2(cx, s.y * 0.05), Vector2(s.x * 0.85, cy), Vector2(cx, s.y * 0.95), Vector2(s.x * 0.15, cy)])
			draw_colored_polygon(pts, color)
			draw_polyline(PackedVector2Array([pts[0], pts[1], pts[2], pts[3], pts[0]]), color.lightened(0.5), 2.0)
		"heart":
			var r: float = s.x * 0.26
			draw_circle(Vector2(cx - r, s.y * 0.38), r, color)
			draw_circle(Vector2(cx + r, s.y * 0.38), r, color)
			draw_colored_polygon(PackedVector2Array([Vector2(cx - r * 2.0, s.y * 0.45), Vector2(cx + r * 2.0, s.y * 0.45), Vector2(cx, s.y * 0.92)]), color)
		"left":
			draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.75, s.y * 0.15), Vector2(s.x * 0.75, s.y * 0.85), Vector2(s.x * 0.2, cy)]), color)
		"right":
			draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.25, s.y * 0.15), Vector2(s.x * 0.25, s.y * 0.85), Vector2(s.x * 0.8, cy)]), color)
		"up":
			draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.15, s.y * 0.75), Vector2(s.x * 0.85, s.y * 0.75), Vector2(cx, s.y * 0.2)]), color)
		"down":
			draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.15, s.y * 0.25), Vector2(s.x * 0.85, s.y * 0.25), Vector2(cx, s.y * 0.8)]), color)
		"pause":
			draw_rect(Rect2(s.x * 0.28, s.y * 0.2, s.x * 0.16, s.y * 0.6), color)
			draw_rect(Rect2(s.x * 0.56, s.y * 0.2, s.x * 0.16, s.y * 0.6), color)
		"magnet":
			draw_arc(Vector2(cx, cy), s.x * 0.28, PI, TAU, 16, color, 6.0)
			draw_line(Vector2(cx - s.x * 0.28, cy), Vector2(cx - s.x * 0.28, s.y * 0.8), color, 6.0)
			draw_line(Vector2(cx + s.x * 0.28, cy), Vector2(cx + s.x * 0.28, s.y * 0.8), color, 6.0)
		"shield":
			draw_colored_polygon(PackedVector2Array([Vector2(s.x * 0.18, s.y * 0.15), Vector2(s.x * 0.82, s.y * 0.15), Vector2(s.x * 0.82, s.y * 0.55), Vector2(cx, s.y * 0.92), Vector2(s.x * 0.18, s.y * 0.55)]), color)
		"speed":
			draw_polyline(PackedVector2Array([Vector2(s.x * 0.2, s.y * 0.2), Vector2(s.x * 0.5, cy), Vector2(s.x * 0.2, s.y * 0.8)]), color, 5.0)
			draw_polyline(PackedVector2Array([Vector2(s.x * 0.5, s.y * 0.2), Vector2(s.x * 0.8, cy), Vector2(s.x * 0.5, s.y * 0.8)]), color, 5.0)
		"double":
			draw_string(ThemeDB.fallback_font, Vector2(0, cy + 9.0), "x2", HORIZONTAL_ALIGNMENT_CENTER, s.x, 26, color)
