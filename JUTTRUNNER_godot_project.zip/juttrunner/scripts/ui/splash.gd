extends Control
## Splash: shows the title while procedural audio is generated, then opens the main menu.


func _ready() -> void:
	UIKit.fill(self)
	add_child(UIKit.make_bg())
	var cc := CenterContainer.new()
	UIKit.fill(cc)
	add_child(cc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 16)
	cc.add_child(vb)
	var title: Label = UIKit.make_label("JUTTRUNNER", 84, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_CENTER)
	title.add_theme_color_override("font_outline_color", UIKit.C_PURPLE)
	title.add_theme_constant_override("outline_size", 10)
	vb.add_child(title)
	vb.add_child(UIKit.make_label("DUNGEON RUNNER", 32, UIKit.C_BLUE, HORIZONTAL_ALIGNMENT_CENTER))
	vb.add_child(UIKit.make_label("Loading...", 24, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_CENTER))
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.8)
	await get_tree().process_frame
	await get_tree().process_frame
	await AudioFX.generate_all()
	SaveData.check_progress_unlocks()
	Gfx.apply(get_viewport(), int(SaveData.get_setting("quality")))
	await get_tree().create_timer(0.6).timeout
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
