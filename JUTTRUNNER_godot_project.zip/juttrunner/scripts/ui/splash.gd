extends Control
## Splash: hero art + title while procedural audio is generated, then opens the main menu.


func _ready() -> void:
	UIKit.fill(self)
	add_child(UIKit.make_bg())
	var art: Texture2D = Art.tex("res://art/splash_bg.png")
	if art != null:
		var tr := TextureRect.new()
		tr.texture = art
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
		tr.anchor_right = 1.0
		tr.anchor_bottom = 0.7
		add_child(tr)
		var fade: TextureRect = UIKit.make_fade(Color(0.016, 0.02, 0.06, 0.0), Color(0.016, 0.02, 0.06, 1.0))
		fade.anchor_right = 1.0
		fade.anchor_top = 0.4
		fade.anchor_bottom = 0.72
		add_child(fade)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 14)
	add_child(vb)
	vb.anchor_left = 0.0
	vb.anchor_right = 1.0
	vb.anchor_top = 0.68
	vb.anchor_bottom = 1.0
	vb.offset_left = 50.0
	vb.offset_right = -50.0
	vb.offset_bottom = -60.0
	vb.add_child(UIKit.make_title("JUTTRUNNER", 84))
	vb.add_child(UIKit.make_label("RUN  -  FIGHT  -  SURVIVE", 28, UIKit.C_BLUE, HORIZONTAL_ALIGNMENT_CENTER))
	var bar: ProgressBar = UIKit.make_bar(0.0, 100.0, UIKit.C_CYAN)
	bar.custom_minimum_size = Vector2(0, 14)
	vb.add_child(bar)
	vb.add_child(UIKit.make_label("Loading...", 24, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_CENTER))
	modulate.a = 0.0
	create_tween().tween_property(self, "modulate:a", 1.0, 0.6)
	create_tween().tween_property(bar, "value", 100.0, 2.4)
	await get_tree().process_frame
	await get_tree().process_frame
	await AudioFX.generate_all()
	SaveData.check_progress_unlocks()
	Gfx.apply(get_viewport(), int(SaveData.get_setting("quality")))
	await get_tree().create_timer(0.8).timeout
	get_tree().change_scene_to_file("res://scenes/main_menu.tscn")
