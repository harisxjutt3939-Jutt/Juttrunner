extends Control
## Main menu: Play, Hunters, Shop, Dungeons, Missions, Settings (+ Player data).

const SCREENS := {
	"player": "res://scenes/ui/player_screen.tscn",
	"hunters": "res://scenes/ui/hunters_screen.tscn",
	"shop": "res://scenes/ui/shop_screen.tscn",
	"dungeons": "res://scenes/ui/dungeons_screen.tscn",
	"missions": "res://scenes/ui/missions_screen.tscn",
	"settings": "res://scenes/ui/settings_screen.tscn",
}

var _preview: HunterPreview
var _bal: Label
var _hunter_label: Label


func _ready() -> void:
	UIKit.fill(self)
	add_child(UIKit.make_bg("res://art/menu_bg.png"))
	var margin := MarginContainer.new()
	UIKit.fill(margin)
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	add_child(margin)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	margin.add_child(vb)

	var top := HBoxContainer.new()
	vb.add_child(top)
	var pb: Button = UIKit.make_button("PLAYER", Vector2(170, 64), UIKit.C_PURPLE, 24)
	pb.pressed.connect(func() -> void: _open("player"))
	top.add_child(pb)
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top.add_child(sp)
	var pill: PanelContainer = UIKit.make_panel(UIKit.C_PANEL, UIKit.C_BLUE)
	pill.size_flags_horizontal = Control.SIZE_SHRINK_END
	var ph := HBoxContainer.new()
	pill.add_child(ph)
	ph.add_child(IconDraw.new("crystal", UIKit.C_BLUE, Vector2(30, 30)))
	_bal = UIKit.make_label("0", 28)
	ph.add_child(_bal)
	top.add_child(pill)

	vb.add_child(UIKit.make_title("JUTTRUNNER", 76))

	_preview = HunterPreview.new()
	_preview.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_preview.custom_minimum_size = Vector2(0, 280)
	vb.add_child(_preview)
	_hunter_label = UIKit.make_label("", 28, UIKit.C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	vb.add_child(_hunter_label)

	var play: Button = UIKit.make_primary("PLAY", Vector2(0, 104), 52)
	play.pressed.connect(_on_play)
	vb.add_child(play)

	for pair in [["HUNTERS", "hunters"], ["SHOP", "shop"], ["DUNGEONS", "dungeons"], ["MISSIONS", "missions"], ["SETTINGS", "settings"]]:
		var b: Button = UIKit.make_button(pair[0], Vector2(0, 66), UIKit.C_BLUE, 30)
		var key: String = pair[1]
		b.pressed.connect(func() -> void: _open(key))
		vb.add_child(b)

	SaveData.crystals_changed.connect(func(v: int) -> void: _bal.text = str(v))
	_refresh()
	AudioFX.play_music()


func _refresh() -> void:
	_bal.text = str(SaveData.crystals())
	var h: String = SaveData.data["hunter"]
	_preview.show_hunter(h, SaveData.get_skin(h))
	var hd: Dictionary = Catalog.HUNTERS[h]
	_hunter_label.text = "%s  -  %s" % [hd["name"], hd["ability_name"]]


func _open(key: String) -> void:
	var s: Control = (load(SCREENS[key]) as PackedScene).instantiate()
	add_child(s)
	s.closed.connect(_refresh)


func _on_play() -> void:
	SaveData.save_game()
	AudioFX.stop_all_loops()
	get_tree().change_scene_to_file("res://scenes/game.tscn")


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		var top: Node = null
		for c in get_children():
			if c is ScreenBase:
				top = c
		if top != null:
			(top as ScreenBase).close()
		else:
			SaveData.save_game()
			get_tree().quit()
