extends CanvasLayer
## Gameplay HUD: hearts, crystal balance, distance, power-up timers, on-screen controls,
## ability button, pause menu and game-over screen. Emits `action(id)` for the game script.

signal action(id: String)

const PU_ORDER: Array = ["magnet", "shield", "speed", "double"]

var _root: Control
var _hearts: HBoxContainer
var _bal: Label
var _dist: Label
var _pu_panels: Dictionary = {}
var _pu_bars: Dictionary = {}
var _ability: Button
var _controls: Control
var _toast: Label
var _toast_tween: Tween
var _pause: Control
var _over: Control
var _over_box: VBoxContainer
var _last_hp: int = -1


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	layer = 10
	_root = Control.new()
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)
	UIKit.fill(_root)
	_build_top()
	_build_controls()
	_build_toast()
	_build_pause()
	_build_over()


# ------------------------------------------------------------------ build
func _build_top() -> void:
	var top := MarginContainer.new()
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right", "top", "bottom"]:
		top.add_theme_constant_override("margin_" + side, 18)
	_root.add_child(top)
	UIKit.anchor_top(top, 110)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(row)
	_hearts = HBoxContainer.new()
	row.add_child(_hearts)
	var sp := Control.new()
	sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(sp)
	row.add_child(IconDraw.new("crystal", UIKit.C_BLUE, Vector2(34, 34)))
	_bal = UIKit.make_label("0", 30)
	row.add_child(_bal)
	_dist = UIKit.make_label("0 m", 30, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_RIGHT)
	_dist.custom_minimum_size.x = 130.0
	row.add_child(_dist)
	var pb: Button = UIKit.make_button("", Vector2(76, 76), UIKit.C_PURPLE)
	var ic := IconDraw.new("pause", UIKit.C_SILVER, Vector2.ZERO)
	UIKit.fill(ic)
	pb.add_child(ic)
	pb.pressed.connect(func() -> void: action.emit("pause"))
	row.add_child(pb)

	var pu_row := HBoxContainer.new()
	pu_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pu_row.add_theme_constant_override("separation", 10)
	_root.add_child(pu_row)
	pu_row.anchor_left = 0.0
	pu_row.anchor_right = 1.0
	pu_row.offset_left = 18.0
	pu_row.offset_top = 118.0
	pu_row.offset_bottom = 170.0
	for id in PU_ORDER:
		var p: PanelContainer = UIKit.make_panel(Color(0.05, 0.05, 0.12, 0.8), Catalog.POWERUPS[id]["color"])
		p.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
		p.visible = false
		var h := HBoxContainer.new()
		h.add_theme_constant_override("separation", 6)
		p.add_child(h)
		h.add_child(IconDraw.new(id, Catalog.POWERUPS[id]["color"], Vector2(34, 34)))
		var bar: ProgressBar = UIKit.make_bar(0, 1, Catalog.POWERUPS[id]["color"])
		bar.custom_minimum_size = Vector2(70, 14)
		bar.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		h.add_child(bar)
		pu_row.add_child(p)
		_pu_panels[id] = p
		_pu_bars[id] = bar


func _ctrl_button(icon_kind: String, size: Vector2, act: String) -> Button:
	var b: Button = UIKit.make_button("", size, UIKit.C_BLUE)
	var ic := IconDraw.new(icon_kind, UIKit.C_SILVER, Vector2.ZERO)
	UIKit.fill(ic)
	b.add_child(ic)
	b.button_down.connect(func() -> void: action.emit(act))
	return b


func _build_controls() -> void:
	_controls = MarginContainer.new()
	_controls.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_controls)
	UIKit.anchor_bottom(_controls, 300)
	_controls.add_theme_constant_override("margin_left", 24)
	_controls.add_theme_constant_override("margin_right", 24)
	_controls.add_theme_constant_override("margin_bottom", 30)
	var row := HBoxContainer.new()
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.alignment = BoxContainer.ALIGNMENT_END
	_controls.add_child(row)
	var left := HBoxContainer.new()
	left.add_theme_constant_override("separation", 14)
	left.size_flags_vertical = Control.SIZE_SHRINK_END
	left.add_child(_ctrl_button("left", Vector2(120, 120), "left"))
	left.add_child(_ctrl_button("right", Vector2(120, 120), "right"))
	row.add_child(left)
	var sp1 := Control.new()
	sp1.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sp1.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row.add_child(sp1)
	var right := VBoxContainer.new()
	right.add_theme_constant_override("separation", 12)
	right.add_child(_ctrl_button("up", Vector2(120, 110), "jump"))
	right.add_child(_ctrl_button("down", Vector2(120, 110), "slide"))
	row.add_child(right)

	# ability button sits above the left/right cluster, always visible
	_ability = UIKit.make_button("ABILITY", Vector2(170, 90), UIKit.C_PURPLE, 22)
	_root.add_child(_ability)
	_ability.anchor_left = 0.5
	_ability.anchor_right = 0.5
	_ability.anchor_top = 1.0
	_ability.anchor_bottom = 1.0
	_ability.offset_left = -85.0
	_ability.offset_right = 85.0
	_ability.offset_top = -420.0
	_ability.offset_bottom = -330.0
	_ability.button_down.connect(func() -> void: action.emit("ability"))


func _build_toast() -> void:
	_toast = UIKit.make_label("", 38, UIKit.C_GOLD, HORIZONTAL_ALIGNMENT_CENTER)
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_toast)
	_toast.anchor_left = 0.0
	_toast.anchor_right = 1.0
	_toast.anchor_top = 0.22
	_toast.anchor_bottom = 0.22
	_toast.offset_bottom = 60.0
	_toast.modulate.a = 0.0


func _build_pause() -> void:
	_pause = ColorRect.new()
	(_pause as ColorRect).color = Color(0, 0, 0, 0.75)
	UIKit.fill(_pause)
	_pause.visible = false
	_root.add_child(_pause)
	var cc := CenterContainer.new()
	UIKit.fill(cc)
	_pause.add_child(cc)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 18)
	cc.add_child(vb)
	vb.add_child(UIKit.make_label("PAUSED", 64, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_CENTER))
	for pair in [["RESUME", "resume"], ["SETTINGS", "settings"], ["RESTART", "restart"], ["MAIN MENU", "menu"]]:
		var b: Button = UIKit.make_button(pair[0], Vector2(420, 96), UIKit.C_BLUE, 32)
		var act: String = pair[1]
		b.pressed.connect(func() -> void: action.emit(act))
		vb.add_child(b)


func _build_over() -> void:
	_over = ColorRect.new()
	(_over as ColorRect).color = Color(0, 0, 0, 0.82)
	UIKit.fill(_over)
	_over.visible = false
	_root.add_child(_over)
	var cc := CenterContainer.new()
	UIKit.fill(cc)
	_over.add_child(cc)
	var p: PanelContainer = UIKit.make_panel(UIKit.C_PANEL, UIKit.C_PURPLE)
	p.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	cc.add_child(p)
	_over_box = VBoxContainer.new()
	_over_box.custom_minimum_size.x = 540.0
	_over_box.add_theme_constant_override("separation", 14)
	p.add_child(_over_box)


# ------------------------------------------------------------------ API used by game.gd
func set_controls_mode(mode: int) -> void:
	_controls.visible = mode != 0


func set_hp(hp: int, max_hp: int) -> void:
	if hp == _last_hp:
		return
	_last_hp = hp
	for c in _hearts.get_children():
		c.queue_free()
	for i in max_hp:
		_hearts.add_child(IconDraw.new("heart", UIKit.C_RED if i < hp else Color("#3a2030"), Vector2(40, 40)))


func update_stats(balance: int, run_crystals: int, distance: int) -> void:
	_bal.text = "%d  +%d" % [balance, run_crystals]
	_dist.text = "%d m" % distance


func update_powerups(active: Dictionary) -> void:
	for id in PU_ORDER:
		var on: bool = active.has(id)
		(_pu_panels[id] as Control).visible = on
		if on:
			var bar: ProgressBar = _pu_bars[id]
			bar.max_value = float(Catalog.POWERUPS[id]["dur"])
			bar.value = float(active[id])


func update_ability(label: String, cooldown: float, active: bool) -> void:
	if active:
		_ability.text = "%s\nACTIVE" % label
		_ability.modulate = Color(1.0, 1.0, 1.0)
	elif cooldown > 0.0:
		_ability.text = "%s\n%d s" % [label, ceili(cooldown)]
		_ability.modulate = Color(0.55, 0.55, 0.65)
	else:
		_ability.text = "%s\nREADY" % label
		_ability.modulate = Color(1.0, 1.0, 1.0)


func toast(text: String, color: Color = UIKit.C_GOLD) -> void:
	_toast.text = text
	_toast.add_theme_color_override("font_color", color)
	if _toast_tween != null:
		_toast_tween.kill()
	_toast.modulate.a = 1.0
	_toast_tween = create_tween()
	_toast_tween.tween_interval(1.0)
	_toast_tween.tween_property(_toast, "modulate:a", 0.0, 0.8)


func show_pause(on: bool) -> void:
	_pause.visible = on


func open_settings() -> void:
	var s: Control = (load("res://scenes/ui/settings_screen.tscn") as PackedScene).instantiate()
	_root.add_child(s)
	s.closed.connect(func() -> void: action.emit("settings_closed"))


func show_game_over(info: Dictionary) -> void:
	for c in _over_box.get_children():
		c.queue_free()
	_controls.visible = false
	_ability.visible = false
	var best: bool = bool(info["new_best"])
	_over_box.add_child(UIKit.make_label("NEW BEST!" if best else "RUN OVER", 58, UIKit.C_GOLD if best else UIKit.C_PURPLE, HORIZONTAL_ALIGNMENT_CENTER))
	var t: float = float(info["time"])
	var rows: Array = [
		["Score", str(info["score"])],
		["Distance", "%d m" % int(info["distance"])],
		["Crystals earned", str(info["crystals"])],
		["Run time", "%d:%02d" % [floori(t / 60.0), int(t) % 60]],
		["Best score", str(info["best_score"])],
	]
	for r in rows:
		var hb := HBoxContainer.new()
		var l: Label = UIKit.make_label(r[0], 28, UIKit.C_DIM)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(l)
		hb.add_child(UIKit.make_label(r[1], 30, UIKit.C_SILVER, HORIZONTAL_ALIGNMENT_RIGHT))
		_over_box.add_child(hb)
	for n in info["notices"]:
		_over_box.add_child(UIKit.make_label(str(n), 24, UIKit.C_GREEN, HORIZONTAL_ALIGNMENT_CENTER, true))
	var again: Button = UIKit.make_button("RESTART", Vector2(0, 100), UIKit.C_BLUE, 34)
	again.pressed.connect(func() -> void: action.emit("restart"))
	_over_box.add_child(again)
	var menu: Button = UIKit.make_button("MAIN MENU", Vector2(0, 84), UIKit.C_PURPLE, 28)
	menu.pressed.connect(func() -> void: action.emit("menu"))
	_over_box.add_child(menu)
	_over.visible = true
