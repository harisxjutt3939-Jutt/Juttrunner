extends ScreenBase
## Shop: hunters, outfits, trails, dungeons, power-up boosts. All prices are in Mana Crystals (MC).

const TABS: Array = ["Hunters", "Outfits", "Trails", "Dungeons", "Boosts"]
var _tab: int = 0
var _preview: HunterPreview
var _pv_hunter: String = ""
var _pv_skin: String = ""


func _init() -> void:
	title_text = "SHOP"


func _populate() -> void:
	if _preview == null:
		_pv_hunter = SaveData.data["hunter"]
		_pv_skin = SaveData.get_skin(_pv_hunter)
		_preview = HunterPreview.new()
		_preview.custom_minimum_size = Vector2(0, 300)
		top_area.add_child(_preview)
		top_area.add_child(tab_buttons(TABS, _tab, _on_tab))
	_preview.show_hunter(_pv_hunter, _pv_skin)
	match _tab:
		0:
			_tab_hunters()
		1:
			_tab_outfits()
		2:
			_tab_trails()
		3:
			_tab_themes()
		4:
			_tab_boosts()


func _on_tab(i: int) -> void:
	_tab = i
	for c in top_area.get_children():
		if c is HBoxContainer:
			c.queue_free()
	top_area.add_child(tab_buttons(TABS, _tab, _on_tab))
	refresh()


func _row(kind: String, id: String, title: String, desc: String, price: int, preview: Callable = Callable()) -> void:
	var owned: bool = SaveData.owns(kind, id)
	var equipped: bool = false
	match kind:
		"hunters":
			equipped = SaveData.data["hunter"] == id
		"trails":
			equipped = SaveData.data["trail"] == id
		"themes":
			equipped = SaveData.data["theme"] == id
		"skins":
			equipped = SaveData.get_skin(str(Catalog.SKINS[id]["hunter"])) == id
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 6)
	if preview.is_valid():
		var pb: Button = UIKit.make_button("VIEW", Vector2(150, 50), UIKit.C_PURPLE, 20)
		pb.pressed.connect(preview)
		vb.add_child(pb)
	var btn: Button
	if owned:
		btn = UIKit.make_button("EQUIPPED" if equipped else "EQUIP", Vector2(150, 64), UIKit.C_GREEN if equipped else UIKit.C_BLUE, 22)
		btn.disabled = equipped
		btn.pressed.connect(func() -> void:
			SaveData.equip(kind, id)
			refresh())
	else:
		btn = UIKit.make_button("%d MC" % price, Vector2(150, 64), UIKit.C_GOLD, 24)
		btn.pressed.connect(func() -> void: _try_buy(kind, id, price, title))
	vb.add_child(btn)
	body.add_child(UIKit.item_row(title, desc, vb))


func _tab_hunters() -> void:
	for id in Catalog.HUNTER_ORDER:
		var hd: Dictionary = Catalog.HUNTERS[id]
		var hid: String = id
		_row("hunters", id, str(hd["name"]), "%s Ability: %s. Free unlock at %d m." % [hd["desc"], hd["ability_name"], hd["unlock_distance"]], int(hd["price"]),
			func() -> void:
				_pv_hunter = hid
				_pv_skin = SaveData.get_skin(hid)
				_preview.show_hunter(_pv_hunter, _pv_skin))


func _tab_outfits() -> void:
	for h in Catalog.HUNTER_ORDER:
		for suffix in ["royal", "void"]:
			var sid: String = h + "_" + suffix
			var sd: Dictionary = Catalog.SKINS[sid]
			var hid: String = h
			var owns_h: bool = SaveData.owns("hunters", h)
			var note: String = "" if owns_h else " (hunter locked)"
			if owns_h or not SaveData.owns("skins", sid):
				_row("skins", sid, "%s - %s" % [Catalog.HUNTERS[h]["name"], sd["name"]], "Outfit for %s%s" % [Catalog.HUNTERS[h]["name"], note], int(sd["price"]),
					func() -> void:
						_pv_hunter = hid
						_pv_skin = sid
						_preview.show_hunter(hid, sid))


func _tab_trails() -> void:
	for id in Catalog.TRAIL_ORDER:
		var td: Dictionary = Catalog.TRAILS[id]
		_row("trails", id, str(td["name"]), "Particle trail behind your hunter.", int(td["price"]))


func _tab_themes() -> void:
	for id in Catalog.THEME_ORDER:
		var td: Dictionary = Catalog.THEMES[id]
		_row("themes", id, str(td["name"]), "%s Free at %d m." % [td["desc"], td["unlock_distance"]], int(td["price"]))


func _tab_boosts() -> void:
	body.add_child(UIKit.make_label("Boosts are consumed automatically at the start of your next run.", 22, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	for id in Catalog.BOOST_ORDER:
		var pd: Dictionary = Catalog.POWERUPS[id]
		var price: int = int(Catalog.BOOST_PRICES[id])
		var have: int = int((SaveData.data["boosts"] as Dictionary).get(id, 0))
		var btn: Button = UIKit.make_button("%d MC" % price, Vector2(150, 70), UIKit.C_GOLD, 24)
		var bid: String = id
		btn.pressed.connect(func() -> void: _try_buy("boost", bid, price, str(pd["name"])))
		body.add_child(UIKit.item_row("%s  (owned: %d)" % [pd["name"], have], str(pd["desc"]), btn, pd["color"]))


func _try_buy(kind: String, id: String, price: int, label: String) -> void:
	if SaveData.crystals() < price:
		AudioFX.play("error")
		UIKit.message(self, "Not enough Mana Crystals!\nYou need %d more." % (price - SaveData.crystals()))
		return
	if kind == "skins" and not SaveData.owns("hunters", str(Catalog.SKINS[id]["hunter"])):
		UIKit.message(self, "Unlock this hunter first.")
		return
	UIKit.confirm(self, "Buy %s for %d Mana Crystals?" % [label, price], func() -> void:
		var r: int = SaveData.BUY_NOT_ENOUGH
		if kind == "boost":
			r = SaveData.buy_boost(id, price)
		else:
			r = SaveData.buy(kind, id, price)
		if r == SaveData.BUY_OK:
			AudioFX.play("buy")
		else:
			AudioFX.play("error")
		refresh())
