class_name UIKit
extends RefCounted
## Neon dark-fantasy UI helpers (black / electric blue / purple / silver).

const C_BG := Color("#04060f")
const C_PANEL := Color("#060d1f")
const C_PANEL2 := Color("#0a1a38")
const C_BLUE := Color("#2aa0ff")
const C_CYAN := Color("#7fd8ff")
const C_PURPLE := Color("#7a5cff")
const C_SILVER := Color("#c8cde0")
const C_DIM := Color("#7f86a3")
const C_GOLD := Color("#ffd24a")
const C_RED := Color("#ff4a5a")
const C_GREEN := Color("#4aff9a")


static func fill(c: Control) -> void:
	c.anchor_left = 0.0
	c.anchor_top = 0.0
	c.anchor_right = 1.0
	c.anchor_bottom = 1.0
	c.offset_left = 0.0
	c.offset_top = 0.0
	c.offset_right = 0.0
	c.offset_bottom = 0.0


static func anchor_top(c: Control, height: float) -> void:
	c.anchor_left = 0.0
	c.anchor_right = 1.0
	c.anchor_top = 0.0
	c.anchor_bottom = 0.0
	c.offset_left = 0.0
	c.offset_right = 0.0
	c.offset_top = 0.0
	c.offset_bottom = height


static func anchor_bottom(c: Control, height: float) -> void:
	c.anchor_left = 0.0
	c.anchor_right = 1.0
	c.anchor_top = 1.0
	c.anchor_bottom = 1.0
	c.offset_left = 0.0
	c.offset_right = 0.0
	c.offset_top = -height
	c.offset_bottom = 0.0


static func style(bg: Color, border: Color, radius: int = 8, border_w: int = 2, glow: float = 0.0) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_w)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(12)
	if glow > 0.0:
		s.shadow_color = Color(border.r, border.g, border.b, 0.4)
		s.shadow_size = int(glow)
	return s


static func make_label(text: String, size: int = 26, color: Color = C_SILVER, align: int = HORIZONTAL_ALIGNMENT_LEFT, wrap: bool = false) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = align as HorizontalAlignment
	l.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	l.add_theme_color_override("font_outline_color", Color.BLACK)
	l.add_theme_constant_override("outline_size", 4)
	if wrap:
		l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		l.custom_minimum_size.x = 200.0
	return l


static func make_title(text: String, size: int = 64) -> Label:
	var l: Label = make_label(text, size, C_CYAN, HORIZONTAL_ALIGNMENT_CENTER)
	l.add_theme_color_override("font_outline_color", Color("#0a4ea8"))
	l.add_theme_constant_override("outline_size", maxi(size / 9, 4))
	return l


static func make_button(text: String, min_size: Vector2 = Vector2(200, 80), accent: Color = C_BLUE, font_size: int = 28, radius: int = 8) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = min_size
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	b.add_theme_color_override("font_color", C_SILVER)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", C_DIM)
	b.add_theme_stylebox_override("normal", style(Color("#07142c"), accent, radius, 2, 8))
	b.add_theme_stylebox_override("hover", style(Color("#0b1d40"), accent.lightened(0.2), radius, 2, 10))
	b.add_theme_stylebox_override("pressed", style(accent.darkened(0.55), accent.lightened(0.4), radius, 2, 12))
	b.add_theme_stylebox_override("disabled", style(Color("#060b18"), C_DIM.darkened(0.4), radius, 2, 0))
	b.add_theme_stylebox_override("focus", StyleBoxEmpty.new())
	b.pressed.connect(func() -> void: AudioFX.play("ui"))
	return b


static func make_primary(text: String, min_size: Vector2 = Vector2(0, 100), font_size: int = 44) -> Button:
	var b: Button = make_button(text, min_size, C_CYAN, font_size, 6)
	b.add_theme_stylebox_override("normal", style(Color("#0b3a78"), C_CYAN, 6, 3, 16))
	b.add_theme_stylebox_override("hover", style(Color("#10478f"), C_CYAN.lightened(0.3), 6, 3, 18))
	b.add_theme_color_override("font_color", Color.WHITE)
	return b


static func make_panel(bg: Color = C_PANEL, border: Color = Color("#1c5fb5")) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", style(Color(bg.r, bg.g, bg.b, 0.95), border, 10, 2, 6))
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return p


static func make_bar(value: float, max_value: float, color: Color = C_BLUE) -> ProgressBar:
	var b := ProgressBar.new()
	b.max_value = max_value
	b.value = value
	b.show_percentage = false
	b.custom_minimum_size = Vector2(120, 18)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_stylebox_override("background", style(Color("#050914"), Color("#1c3558"), 8, 1))
	b.add_theme_stylebox_override("fill", style(color, color.lightened(0.3), 8, 0, 6))
	return b


static func make_fade(c0: Color, c1: Color) -> TextureRect:
	var g := Gradient.new()
	g.colors = PackedColorArray([c0, c1])
	g.offsets = PackedFloat32Array([0.0, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0.5, 0.0)
	gt.fill_to = Vector2(0.5, 1.0)
	gt.width = 8
	gt.height = 128
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return tr


static func make_bg(art_path: String = "") -> Control:
	var holder := Control.new()
	holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill(holder)
	var g := Gradient.new()
	g.colors = PackedColorArray([Color("#03050d"), Color("#0a1233"), Color("#04060f")])
	g.offsets = PackedFloat32Array([0.0, 0.55, 1.0])
	var gt := GradientTexture2D.new()
	gt.gradient = g
	gt.fill_from = Vector2(0.5, 0.0)
	gt.fill_to = Vector2(0.5, 1.0)
	gt.width = 8
	gt.height = 256
	var tr := TextureRect.new()
	tr.texture = gt
	tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	tr.stretch_mode = TextureRect.STRETCH_SCALE
	tr.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fill(tr)
	holder.add_child(tr)
	if art_path != "":
		var t: Texture2D = Art.tex(art_path)
		if t != null:
			var art := TextureRect.new()
			art.texture = t
			art.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
			art.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
			art.modulate = Color(1, 1, 1, 0.4)
			art.mouse_filter = Control.MOUSE_FILTER_IGNORE
			fill(art)
			holder.add_child(art)
	return holder


static func item_row(title: String, desc: String, right: Control, accent: Color = C_BLUE, thumb: Texture2D = null) -> PanelContainer:
	var p: PanelContainer = make_panel(C_PANEL, accent.darkened(0.2))
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 14)
	p.add_child(hb)
	if thumb != null:
		var tr := TextureRect.new()
		tr.texture = thumb
		tr.custom_minimum_size = Vector2(84, 84)
		tr.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		tr.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		tr.clip_contents = true
		hb.add_child(tr)
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_theme_constant_override("separation", 4)
	hb.add_child(vb)
	vb.add_child(make_label(title, 30, C_SILVER))
	var d: Label = make_label(desc, 22, C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true)
	d.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vb.add_child(d)
	hb.add_child(right)
	return p


static func _overlay(parent: Control) -> ColorRect:
	var o := ColorRect.new()
	o.color = Color(0, 0, 0, 0.8)
	o.mouse_filter = Control.MOUSE_FILTER_STOP
	fill(o)
	parent.add_child(o)
	return o


static func _dialog_box(overlay: Control) -> VBoxContainer:
	var cc := CenterContainer.new()
	fill(cc)
	overlay.add_child(cc)
	var p: PanelContainer = make_panel(C_PANEL, C_PURPLE)
	p.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	cc.add_child(p)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 22)
	p.add_child(vb)
	return vb


static func confirm(parent: Control, text: String, on_yes: Callable, yes_text: String = "CONFIRM") -> void:
	var overlay: ColorRect = _overlay(parent)
	var box: VBoxContainer = _dialog_box(overlay)
	var lbl: Label = make_label(text, 30, C_SILVER, HORIZONTAL_ALIGNMENT_CENTER, true)
	lbl.custom_minimum_size.x = 480.0
	box.add_child(lbl)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 16)
	box.add_child(row)
	var no: Button = make_button("CANCEL", Vector2(220, 84), C_DIM)
	var yes: Button = make_button(yes_text, Vector2(220, 84), C_BLUE)
	no.pressed.connect(overlay.queue_free)
	var yes_cb := func() -> void:
		overlay.queue_free()
		on_yes.call()
	yes.pressed.connect(yes_cb)
	row.add_child(no)
	row.add_child(yes)


static func message(parent: Control, text: String, color: Color = C_RED) -> void:
	var overlay: ColorRect = _overlay(parent)
	var box: VBoxContainer = _dialog_box(overlay)
	var lbl: Label = make_label(text, 30, color, HORIZONTAL_ALIGNMENT_CENTER, true)
	lbl.custom_minimum_size.x = 480.0
	box.add_child(lbl)
	var ok: Button = make_button("OK", Vector2(220, 84), C_BLUE)
	ok.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	ok.pressed.connect(overlay.queue_free)
	box.add_child(ok)
