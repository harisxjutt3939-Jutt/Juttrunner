extends ScreenBase
## Missions, achievements and distance milestones.

const TABS: Array = ["Missions", "Achievements", "Milestones"]
var _tab: int = 0
var _tabs_built: bool = false


func _init() -> void:
	title_text = "MISSIONS"


func _populate() -> void:
	if not _tabs_built:
		_tabs_built = true
		top_area.add_child(tab_buttons(TABS, _tab, _on_tab))
	match _tab:
		0:
			_missions()
		1:
			_achievements()
		2:
			_milestones()


func _on_tab(i: int) -> void:
	_tab = i
	for c in top_area.get_children():
		c.queue_free()
	top_area.add_child(tab_buttons(TABS, _tab, _on_tab))
	refresh()


func _claim_button(ready: bool, reward: int, on_claim: Callable) -> Button:
	var b: Button = UIKit.make_button("CLAIM\n+%d" % reward if ready else "+%d MC" % reward, Vector2(150, 80), UIKit.C_GREEN if ready else UIKit.C_DIM, 22)
	b.disabled = not ready
	b.pressed.connect(on_claim)
	return b


func _missions() -> void:
	var ms: Array = SaveData.data["missions"]
	for i in ms.size():
		var m: Dictionary = ms[i]
		var idx: int = i
		var done: bool = SaveData.mission_done(i)
		var btn: Button = _claim_button(done, int(m["reward"]), func() -> void:
			SaveData.claim_mission(idx)
			AudioFX.play("buy")
			refresh())
		var row: PanelContainer = UIKit.item_row(str(m["text"]), "Progress: %d / %d" % [m["progress"], m["target"]], btn)
		body.add_child(row)
		body.add_child(UIKit.make_bar(float(m["progress"]), float(m["target"]), UIKit.C_PURPLE))


func _achievements() -> void:
	for a in Catalog.ACHIEVEMENTS:
		var done: bool = SaveData.ach_done(a)
		var claimed: bool = SaveData.ach_claimed(a)
		var ad: Dictionary = a
		var btn: Button = _claim_button(done and not claimed, int(a["reward"]), func() -> void:
			SaveData.claim_achievement(ad)
			AudioFX.play("buy")
			refresh())
		if claimed:
			btn.text = "DONE"
		var cur: int = mini(int(SaveData.stat(a["stat"])), int(a["target"]))
		body.add_child(UIKit.item_row(str(a["name"]), "%s  (%d / %d)" % [a["desc"], cur, a["target"]], btn, UIKit.C_PURPLE))


func _milestones() -> void:
	body.add_child(UIKit.make_label("Reach these distances in a single run to earn bonus crystals automatically every run.", 22, UIKit.C_DIM, HORIZONTAL_ALIGNMENT_LEFT, true))
	var best: int = int(SaveData.data["best_distance"])
	for ms in Catalog.MILESTONES:
		var reached: bool = best >= int(ms[0])
		var tag: Label = UIKit.make_label("+%d MC" % int(ms[1]), 26, UIKit.C_GREEN if reached else UIKit.C_GOLD)
		body.add_child(UIKit.item_row("%d m" % int(ms[0]), "Reached" if reached else "Not yet reached", tag))
