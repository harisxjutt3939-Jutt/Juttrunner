class_name Art
extends RefCounted
## Optional art lookup. Returns null when a file is missing so UI can fall back to placeholders.

static var _cache: Dictionary = {}


static func tex(path: String) -> Texture2D:
	if _cache.has(path):
		return _cache[path]
	var t: Texture2D = null
	if ResourceLoader.exists(path):
		t = load(path) as Texture2D
	_cache[path] = t
	return t


static func hunter(id: String) -> Texture2D:
	return tex("res://art/hunters/%s.png" % id)
