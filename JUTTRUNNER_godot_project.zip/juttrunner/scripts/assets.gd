class_name Assets
extends RefCounted
## Shared meshes and materials. Everything is created once and reused (low memory, few draw states).

static var _meshes: Dictionary = {}
static var _mats: Dictionary = {}


static func box(size: Vector3) -> BoxMesh:
	var key: String = "box_%s" % str(size)
	if not _meshes.has(key):
		var m := BoxMesh.new()
		m.size = size
		_meshes[key] = m
	return _meshes[key]


static func cylinder(top: float, bottom: float, height: float, segments: int = 8) -> CylinderMesh:
	var key: String = "cyl_%s_%s_%s_%s" % [top, bottom, height, segments]
	if not _meshes.has(key):
		var m := CylinderMesh.new()
		m.top_radius = top
		m.bottom_radius = bottom
		m.height = height
		m.radial_segments = segments
		m.rings = 1
		_meshes[key] = m
	return _meshes[key]


static func sphere(radius: float, segments: int = 10) -> SphereMesh:
	var key: String = "sph_%s_%s" % [radius, segments]
	if not _meshes.has(key):
		var m := SphereMesh.new()
		m.radius = radius
		m.height = radius * 2.0
		m.radial_segments = segments
		m.rings = maxi(segments / 2, 3)
		_meshes[key] = m
	return _meshes[key]


static func torus(inner: float, outer: float) -> TorusMesh:
	var key: String = "tor_%s_%s" % [inner, outer]
	if not _meshes.has(key):
		var m := TorusMesh.new()
		m.inner_radius = inner
		m.outer_radius = outer
		m.rings = 24
		m.ring_segments = 8
		_meshes[key] = m
	return _meshes[key]


static func quad(size: Vector2) -> QuadMesh:
	var key: String = "quad_%s" % str(size)
	if not _meshes.has(key):
		var m := QuadMesh.new()
		m.size = size
		_meshes[key] = m
	return _meshes[key]


static func add(parent: Node3D, mesh: Mesh, material: Material, pos: Vector3 = Vector3.ZERO, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.material_override = material
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(mi)
	return mi


static func colored(c: Color, emission: float = 0.0) -> StandardMaterial3D:
	var key: String = "col_%s_%s" % [c.to_html(), str(emission)]
	if _mats.has(key):
		return _mats[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.8
	if emission > 0.0:
		m.emission_enabled = true
		m.emission = c
		m.emission_energy_multiplier = emission
	_mats[key] = m
	return m


static func _glow(m: StandardMaterial3D, c: Color, energy: float) -> void:
	m.albedo_color = c
	m.emission_enabled = true
	m.emission = c
	m.emission_energy_multiplier = energy


static func mat(mat_name: String) -> StandardMaterial3D:
	if _mats.has(mat_name):
		return _mats[mat_name]
	var m := StandardMaterial3D.new()
	m.roughness = 0.9
	match mat_name:
		"wall":
			m.albedo_color = Color("#3a3d4a")
		"floor":
			m.albedo_color = Color("#2a2c36")
		"stone_light":
			m.albedo_color = Color("#5b5f70")
		"dark":
			m.albedo_color = Color("#101118")
		"iron":
			m.albedo_color = Color("#4a4f5c")
			m.metallic = 0.6
			m.roughness = 0.5
		"wood":
			m.albedo_color = Color("#5a3d28")
		"bone":
			m.albedo_color = Color("#d8d2c0")
		"fur":
			m.albedo_color = Color("#2b2230")
		"glow":
			_glow(m, Color("#4aa8ff"), 1.6)
		"glow_dim":
			_glow(m, Color("#4aa8ff"), 0.7)
		"void_glow":
			_glow(m, Color("#4aa8ff"), 1.2)
		"crystal":
			_glow(m, Color("#3ab4ff"), 2.2)
		"crystal_violet":
			_glow(m, Color("#b05aff"), 2.0)
		"eye_red":
			_glow(m, Color("#ff2a2a"), 3.0)
		"eye_blue":
			_glow(m, Color("#5ad0ff"), 3.0)
		"eye_purple":
			_glow(m, Color("#c070ff"), 3.0)
		"fire":
			_glow(m, Color("#ff8a2a"), 2.5)
		"shadow_body":
			m.albedo_color = Color("#07070c")
			m.emission_enabled = true
			m.emission = Color("#2a1050")
			m.emission_energy_multiplier = 0.6
		"portal":
			_glow(m, Color("#8a5cff"), 1.5)
			m.albedo_color = Color(0.54, 0.36, 1.0, 0.18)
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
			m.cull_mode = BaseMaterial3D.CULL_DISABLED
		"ice":
			_glow(m, Color("#6fd0ff"), 0.6)
			m.albedo_color = Color(0.62, 0.91, 1.0, 0.45)
			m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		_:
			m.albedo_color = Color.WHITE
	_mats[mat_name] = m
	return m


static func apply_theme(theme_id: String) -> void:
	var t: Dictionary = Catalog.THEMES[theme_id]
	var wall: Color = t["wall"]
	var glow: Color = t["glow"]
	mat("wall").albedo_color = wall
	mat("floor").albedo_color = t["floor"]
	mat("stone_light").albedo_color = wall.lightened(0.18)
	for n in ["glow", "glow_dim", "void_glow"]:
		var m: StandardMaterial3D = mat(n)
		m.albedo_color = glow
		m.emission = glow
