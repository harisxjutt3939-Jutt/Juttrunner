class_name Entity
extends Node3D
## Pooled world object: obstacle / enemy / trap, Mana Crystal, or power-up pickup.
## The world is built facing -Z; the player looks down -Z, so the "front" of every object is +Z.

var kind: String = ""
var category: String = "obstacle"  # "obstacle" | "crystal" | "powerup"
var pu_kind: String = ""
var y0: float = 0.0   # hitbox bottom, relative to position.y
var y1: float = 1.0   # hitbox top, relative to position.y
var half_x: float = 0.8
var half_z: float = 0.5
var approach: float = 0.0   # extra speed (towards the player) for enemies
var enemy: bool = false
var active: bool = false
var frozen: bool = false
var alerted: bool = false

var _visual: Node3D
var _ice: MeshInstance3D
var _arm: Node3D
var _head: Node3D
var _phase: float = 0.0


func build(k: String) -> void:
	kind = k
	_phase = randf() * TAU
	_visual = Node3D.new()
	add_child(_visual)
	match k:
		"crystal":
			_build_crystal()
		"block":
			_build_block()
		"spikes":
			_build_spikes()
		"beam":
			_build_beam()
		"wall":
			_build_wall()
		"skeleton":
			_build_skeleton()
		"beast":
			_build_beast()
		"shadow":
			_build_shadow()
		_:
			if k.begins_with("pu_"):
				_build_powerup(k.substr(3))
	if category == "obstacle":
		var size := Vector3(half_x * 2.0 + 0.1, y1 - y0 + 0.1, half_z * 2.0 + 0.1)
		_ice = Assets.add(self, Assets.box(size), Assets.mat("ice"), Vector3(0, (y0 + y1) * 0.5, 0))
		_ice.visible = false


func reset_state() -> void:
	active = true
	frozen = false
	alerted = false
	visible = true
	position = Vector3.ZERO
	rotation = Vector3.ZERO
	if _ice != null:
		_ice.visible = false
	if _visual != null:
		_visual.position = Vector3.ZERO
		_visual.rotation = Vector3.ZERO


func set_frozen(on: bool) -> void:
	frozen = on
	if _ice != null:
		_ice.visible = on


func animate(t: float, delta: float) -> void:
	match kind:
		"crystal":
			_visual.rotation.y += delta * 2.6
			_visual.position.y = sin(t * 3.0 + _phase) * 0.08
		"skeleton":
			if not frozen:
				_visual.position.y = absf(sin(t * 6.0 + _phase)) * 0.08
				_arm.rotation.x = sin(t * 5.0 + _phase) * 0.9
		"beast":
			if not frozen:
				_visual.position.y = absf(sin(t * 9.0 + _phase)) * 0.07
				_head.rotation.x = sin(t * 5.0 + _phase) * 0.15
		"shadow":
			if not frozen:
				_visual.position.y = sin(t * 2.2 + _phase) * 0.15
		_:
			if category == "powerup":
				_visual.rotation.y += delta * 2.0
				_visual.position.y = sin(t * 3.0 + _phase) * 0.12


# ------------------------------------------------------------------ builders
func _build_crystal() -> void:
	category = "crystal"
	y0 = -0.3
	y1 = 0.3
	half_x = 0.5
	half_z = 0.5
	Assets.add(_visual, Assets.cylinder(0.0, 0.2, 0.4, 5), Assets.mat("crystal"), Vector3(0, 0.2, 0))
	Assets.add(_visual, Assets.cylinder(0.2, 0.0, 0.3, 5), Assets.mat("crystal"), Vector3(0, -0.15, 0))


func _build_block() -> void:
	y0 = 0.0
	y1 = 0.9
	half_x = 0.9
	half_z = 0.5
	Assets.add(_visual, Assets.box(Vector3(1.8, 0.9, 1.0)), Assets.mat("wall"), Vector3(0, 0.45, 0))
	Assets.add(_visual, Assets.box(Vector3(1.9, 0.14, 1.1)), Assets.mat("stone_light"), Vector3(0, 0.93, 0))
	Assets.add(_visual, Assets.box(Vector3(1.1, 0.08, 0.03)), Assets.mat("glow"), Vector3(0, 0.5, 0.52))


func _build_spikes() -> void:
	y0 = 0.0
	y1 = 0.7
	half_x = 0.9
	half_z = 0.7
	Assets.add(_visual, Assets.box(Vector3(1.9, 0.12, 1.4)), Assets.mat("iron"), Vector3(0, 0.06, 0))
	var steel: StandardMaterial3D = Assets.colored(Color("#b8c0d0"))
	for ix in 3:
		for iz in 3:
			Assets.add(_visual, Assets.cylinder(0.0, 0.12, 0.6, 5), steel, Vector3(-0.6 + ix * 0.6, 0.42, -0.4 + iz * 0.4))


func _build_beam() -> void:
	y0 = 1.1
	y1 = 1.8
	half_x = 1.0
	half_z = 0.4
	Assets.add(_visual, Assets.box(Vector3(2.0, 0.6, 0.7)), Assets.mat("iron"), Vector3(0, 1.4, 0))
	Assets.add(_visual, Assets.box(Vector3(1.8, 0.06, 0.72)), Assets.mat("glow"), Vector3(0, 1.12, 0))
	Assets.add(_visual, Assets.cylinder(0.04, 0.04, 4.8, 4), Assets.mat("iron"), Vector3(-0.8, 4.1, 0))
	Assets.add(_visual, Assets.cylinder(0.04, 0.04, 4.8, 4), Assets.mat("iron"), Vector3(0.8, 4.1, 0))


func _build_wall() -> void:
	y0 = 0.0
	y1 = 3.2
	half_x = 0.95
	half_z = 0.5
	Assets.add(_visual, Assets.box(Vector3(1.9, 3.2, 1.0)), Assets.mat("wall"), Vector3(0, 1.6, 0))
	Assets.add(_visual, Assets.box(Vector3(2.0, 0.2, 1.1)), Assets.mat("stone_light"), Vector3(0, 3.2, 0))
	Assets.add(_visual, Assets.box(Vector3(0.16, 1.4, 0.03)), Assets.mat("glow"), Vector3(0, 1.8, 0.52))
	Assets.add(_visual, Assets.box(Vector3(0.7, 0.16, 0.03)), Assets.mat("glow"), Vector3(0, 1.4, 0.52))


func _build_skeleton() -> void:
	enemy = true
	approach = 2.5
	y0 = 0.0
	y1 = 2.0
	half_x = 0.55
	half_z = 0.4
	var bone: StandardMaterial3D = Assets.mat("bone")
	Assets.add(_visual, Assets.box(Vector3(0.5, 0.6, 0.3)), bone, Vector3(0, 1.25, 0))
	Assets.add(_visual, Assets.box(Vector3(0.3, 0.25, 0.2)), bone, Vector3(0, 0.82, 0))
	Assets.add(_visual, Assets.box(Vector3(0.12, 0.8, 0.12)), bone, Vector3(-0.12, 0.4, 0))
	Assets.add(_visual, Assets.box(Vector3(0.12, 0.8, 0.12)), bone, Vector3(0.12, 0.4, 0))
	Assets.add(_visual, Assets.sphere(0.2), bone, Vector3(0, 1.75, 0))
	Assets.add(_visual, Assets.box(Vector3(0.07, 0.07, 0.03)), Assets.mat("eye_blue"), Vector3(-0.08, 1.77, 0.18))
	Assets.add(_visual, Assets.box(Vector3(0.07, 0.07, 0.03)), Assets.mat("eye_blue"), Vector3(0.08, 1.77, 0.18))
	_arm = Node3D.new()
	_arm.position = Vector3(0.36, 1.45, 0)
	_visual.add_child(_arm)
	Assets.add(_arm, Assets.box(Vector3(0.1, 0.6, 0.1)), bone, Vector3(0, -0.3, 0))
	Assets.add(_arm, Assets.box(Vector3(0.07, 1.0, 0.03)), Assets.colored(Color("#aab4cc"), 0.4), Vector3(0, -0.6, 0.12))
	Assets.add(_visual, Assets.cylinder(0.3, 0.3, 0.06, 10), Assets.mat("wood"), Vector3(-0.4, 1.2, 0.12), Vector3(90, 0, 0))


func _build_beast() -> void:
	enemy = true
	approach = 3.5
	y0 = 0.0
	y1 = 1.1
	half_x = 0.7
	half_z = 0.8
	var fur: StandardMaterial3D = Assets.mat("fur")
	Assets.add(_visual, Assets.box(Vector3(1.0, 0.7, 1.5)), fur, Vector3(0, 0.65, 0))
	_head = Node3D.new()
	_head.position = Vector3(0, 0.85, 0.95)
	_visual.add_child(_head)
	Assets.add(_head, Assets.box(Vector3(0.6, 0.5, 0.6)), fur, Vector3.ZERO)
	Assets.add(_head, Assets.box(Vector3(0.1, 0.08, 0.03)), Assets.mat("eye_red"), Vector3(-0.15, 0.07, 0.31))
	Assets.add(_head, Assets.box(Vector3(0.1, 0.08, 0.03)), Assets.mat("eye_red"), Vector3(0.15, 0.07, 0.31))
	Assets.add(_head, Assets.cylinder(0.0, 0.08, 0.4, 5), Assets.mat("bone"), Vector3(-0.2, 0.4, 0.0), Vector3(0, 0, 15))
	Assets.add(_head, Assets.cylinder(0.0, 0.08, 0.4, 5), Assets.mat("bone"), Vector3(0.2, 0.4, 0.0), Vector3(0, 0, -15))
	for sx in [-0.35, 0.35]:
		for sz in [-0.5, 0.5]:
			Assets.add(_visual, Assets.box(Vector3(0.2, 0.5, 0.2)), fur, Vector3(sx, 0.25, sz))
	Assets.add(_visual, Assets.box(Vector3(0.15, 0.15, 0.7)), fur, Vector3(0, 0.8, -1.0))


func _build_shadow() -> void:
	enemy = true
	approach = 1.5
	y0 = 1.0
	y1 = 2.1
	half_x = 0.6
	half_z = 0.5
	var body: StandardMaterial3D = Assets.mat("shadow_body")
	Assets.add(_visual, Assets.sphere(0.5, 10), body, Vector3(0, 1.6, 0))
	for sx in [-0.28, 0.0, 0.28]:
		Assets.add(_visual, Assets.cylinder(0.22, 0.0, 0.9, 5), body, Vector3(sx, 1.0, 0.0))
	Assets.add(_visual, Assets.box(Vector3(0.14, 0.06, 0.03)), Assets.mat("eye_purple"), Vector3(-0.18, 1.66, 0.47))
	Assets.add(_visual, Assets.box(Vector3(0.14, 0.06, 0.03)), Assets.mat("eye_purple"), Vector3(0.18, 1.66, 0.47))


func _build_powerup(pu: String) -> void:
	category = "powerup"
	pu_kind = pu
	y0 = -0.45
	y1 = 0.45
	half_x = 0.7
	half_z = 0.7
	var c: Color = Catalog.POWERUPS[pu]["color"]
	var glow: StandardMaterial3D = Assets.colored(c, 2.2)
	Assets.add(_visual, Assets.torus(0.34, 0.42), glow, Vector3.ZERO, Vector3(90, 0, 0))
	match pu:
		"magnet":
			Assets.add(_visual, Assets.box(Vector3(0.28, 0.28, 0.28)), glow)
		"shield":
			Assets.add(_visual, Assets.sphere(0.22, 8), glow)
		"speed":
			Assets.add(_visual, Assets.cylinder(0.0, 0.2, 0.4, 5), glow, Vector3.ZERO, Vector3(90, 0, 0))
		"double":
			Assets.add(_visual, Assets.sphere(0.13, 6), glow, Vector3(-0.13, 0, 0))
			Assets.add(_visual, Assets.sphere(0.13, 6), glow, Vector3(0.13, 0, 0))
