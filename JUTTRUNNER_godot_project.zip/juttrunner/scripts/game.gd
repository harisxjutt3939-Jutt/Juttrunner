extends Node3D
## Gameplay controller: input, speed/difficulty, power-ups, abilities, scoring, pause, game over.

const START_SPEED := 11.0
const MAX_SPEED := 27.0
const ACCEL := 0.2
const SWIPE_MIN := 45.0
const ABILITY_COLORS := {
	"slow": Color("#8a5cff"), "dash": Color("#4aa8ff"), "freeze": Color("#9fe8ff"),
	"ward": Color("#ff8a2a"), "phase": Color("#cfd6ff"),
}

@onready var world = $World
@onready var player = $Player
@onready var cam_rig = $CameraRig
@onready var fx = $Effects
@onready var hud = $HUD
@onready var env_node: WorldEnvironment = $WorldEnvironment
@onready var sun: DirectionalLight3D = $DirectionalLight3D

var state: String = "running"   # running | paused | over
var distance: float = 0.0
var run_time: float = 0.0
var crystals_run: int = 0
var quality: int = 1
var theme_id: String = "catacombs"
var powerups: Dictionary = {}
var ability_cd: float = 3.0
var ability_time: float = 0.0
var ability_id: String = ""
var next_milestone: int = 0
var swipes_enabled: bool = true

var _touch_start: Dictionary = {}
var _touch_done: Dictionary = {}
var _hud_timer: float = 0.0
var _dust: CPUParticles3D


func _ready() -> void:
	quality = int(SaveData.get_setting("quality"))
	Gfx.apply(get_viewport(), quality)
	var hunter_id: String = SaveData.data["hunter"]
	theme_id = SaveData.data["theme"]
	_setup_environment()
	player.setup(hunter_id, SaveData.get_skin(hunter_id), SaveData.data["trail"], quality)
	world.setup(theme_id, quality)
	fx.quality = quality
	_setup_dust()

	world.crystal_collected.connect(_on_crystal)
	world.powerup_collected.connect(_on_powerup)
	world.obstacle_hit.connect(_on_hit)
	world.enemy_near.connect(func() -> void: AudioFX.play("enemy", 1.0, -8.0))
	hud.action.connect(_on_hud_action)
	_apply_controls_mode()
	hud.set_hp(player.hp, player.max_hp)

	for b in SaveData.consume_boosts():
		_activate_powerup(str(b))
	AudioFX.play_music()
	AudioFX.play_ambience()


func _apply_controls_mode() -> void:
	var mode: int = int(SaveData.get_setting("controls"))
	swipes_enabled = mode != 1
	hud.set_controls_mode(mode)


func _setup_environment() -> void:
	var t: Dictionary = Catalog.THEMES[theme_id]
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = t["fog"]
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = t["ambient"]
	env.ambient_light_energy = 1.0
	env.fog_enabled = true
	env.fog_light_color = t["fog"]
	env.fog_density = 0.03
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	if quality >= 2:
		env.glow_enabled = true
		env.glow_intensity = 0.7
		env.glow_bloom = 0.05
	env_node.environment = env
	sun.light_color = t["light"]
	sun.light_energy = 0.35
	sun.shadow_enabled = false
	sun.rotation_degrees = Vector3(-50, 20, 0)


func _setup_dust() -> void:
	var amount: int = Gfx.dust_amount(quality)
	if amount <= 0:
		return
	var t: Dictionary = Catalog.THEMES[theme_id]
	_dust = CPUParticles3D.new()
	_dust.amount = amount
	_dust.lifetime = 3.0
	_dust.local_coords = false
	_dust.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	_dust.emission_box_extents = Vector3(4.0, 2.5, 14.0)
	_dust.direction = Vector3(0, 0, 1)
	_dust.spread = 5.0
	_dust.gravity = Vector3.ZERO
	_dust.initial_velocity_min = START_SPEED
	_dust.initial_velocity_max = START_SPEED
	_dust.mesh = Assets.sphere(0.04, 4)
	_dust.material_override = Assets.colored(t["glow"], 2.0)
	_dust.position = Vector3(0, 3.0, -14.0)
	add_child(_dust)


# ------------------------------------------------------------------ input
func _input(event: InputEvent) -> void:
	if state != "running":
		return
	if event is InputEventScreenTouch:
		if event.pressed:
			_touch_start[event.index] = event.position
			_touch_done[event.index] = false
		else:
			_touch_start.erase(event.index)
			_touch_done.erase(event.index)
	elif event is InputEventScreenDrag and swipes_enabled:
		if _touch_start.has(event.index) and not _touch_done[event.index]:
			var d: Vector2 = event.position - _touch_start[event.index]
			if d.length() > SWIPE_MIN:
				_touch_done[event.index] = true
				if absf(d.x) > absf(d.y):
					_do_lane(1 if d.x > 0.0 else -1)
				elif d.y < 0.0:
					_do_jump()
				else:
					_do_slide()
	elif event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_LEFT, KEY_A:
				_do_lane(-1)
			KEY_RIGHT, KEY_D:
				_do_lane(1)
			KEY_UP, KEY_W, KEY_SPACE:
				_do_jump()
			KEY_DOWN, KEY_S:
				_do_slide()
			KEY_E, KEY_Q:
				use_ability()
			KEY_ESCAPE, KEY_P:
				pause_game()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_GO_BACK_REQUEST:
		if state == "running":
			pause_game()
		elif state == "paused":
			resume_game()
	elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		pause_game()
		SaveData.save_game()


func _do_lane(dir: int) -> void:
	if player.change_lane(dir):
		AudioFX.play("lane")


func _do_jump() -> void:
	if player.jump():
		AudioFX.play("jump")
		SaveData.report_event("jumps", 1)


func _do_slide() -> void:
	if player.slide():
		AudioFX.play("slide")
		SaveData.report_event("slides", 1)


func _on_hud_action(id: String) -> void:
	match id:
		"left":
			if state == "running":
				_do_lane(-1)
		"right":
			if state == "running":
				_do_lane(1)
		"jump":
			if state == "running":
				_do_jump()
		"slide":
			if state == "running":
				_do_slide()
		"ability":
			use_ability()
		"pause":
			pause_game()
		"resume":
			resume_game()
		"settings":
			hud.open_settings()
		"settings_closed":
			_apply_controls_mode()
			AudioFX.apply_settings()
		"restart":
			get_tree().paused = false
			SaveData.save_game()
			get_tree().reload_current_scene()
		"menu":
			get_tree().paused = false
			SaveData.save_game()
			AudioFX.stop_all_loops()
			get_tree().change_scene_to_file("res://scenes/main_menu.tscn")


# ------------------------------------------------------------------ main loop
func _process(delta: float) -> void:
	if state == "over":
		return
	delta = minf(delta, 0.05)
	run_time += delta
	_update_powerups(delta)
	if ability_cd > 0.0:
		ability_cd -= delta
	if ability_time > 0.0:
		ability_time -= delta
		if ability_time <= 0.0:
			_end_ability()

	var spd: float = _current_speed()
	distance += spd * delta
	world.difficulty = clampf(distance / 3500.0, 0.0, 1.0)
	world.magnet_on = powerups.has("magnet")
	world.skip_obstacles = ability_time > 0.0 and ability_id == "phase"
	player.tick(delta, spd)
	world.update_world(delta, spd, player.position.x, player.position.y, player.position.y + player.body_height())
	cam_rig.follow(player.position.x, delta, spd / MAX_SPEED)
	fx.speed = spd
	if _dust != null:
		_dust.initial_velocity_min = spd
		_dust.initial_velocity_max = spd
	_check_milestones()

	_hud_timer += delta
	if _hud_timer > 0.08:
		_hud_timer = 0.0
		hud.update_stats(SaveData.crystals(), crystals_run, int(distance))
		hud.update_powerups(powerups)
		hud.update_ability(str(player.stats["ability_name"]), ability_cd, ability_time > 0.0)


func _current_speed() -> float:
	var base: float = minf(MAX_SPEED, START_SPEED + ACCEL * run_time)
	base *= float(player.stats["speed"])
	var m: float = 1.0
	if powerups.has("speed"):
		m *= 1.5
	if ability_time > 0.0:
		if ability_id == "dash":
			m *= 2.0
		elif ability_id == "slow":
			m *= 0.65
	return base * m


func _check_milestones() -> void:
	var ms: Array = Catalog.MILESTONES
	while next_milestone < ms.size() and distance >= float(ms[next_milestone][0]):
		var bonus: int = int(ms[next_milestone][1])
		SaveData.add_crystals(bonus)
		crystals_run += bonus
		AudioFX.play("milestone")
		hud.toast("%d m!  +%d crystals" % [int(ms[next_milestone][0]), bonus])
		next_milestone += 1


# ------------------------------------------------------------------ power-ups & abilities
func _activate_powerup(id: String) -> void:
	powerups[id] = float(Catalog.POWERUPS[id]["dur"])
	_refresh_aura()


func _update_powerups(delta: float) -> void:
	var expired: Array = []
	for id in powerups.keys():
		powerups[id] = float(powerups[id]) - delta
		if float(powerups[id]) <= 0.0:
			expired.append(id)
	for id in expired:
		powerups.erase(id)
	if not expired.is_empty():
		_refresh_aura()


func _refresh_aura() -> void:
	if ability_time > 0.0:
		player.set_aura(ABILITY_COLORS[ability_id], true)
	elif powerups.has("speed"):
		player.set_aura(Catalog.POWERUPS["speed"]["color"], true)
	elif powerups.has("shield"):
		player.set_aura(Catalog.POWERUPS["shield"]["color"], true)
	else:
		player.set_aura(Color.WHITE, false)


func use_ability() -> void:
	if state != "running" or ability_cd > 0.0 or ability_time > 0.0:
		return
	var st: Dictionary = player.stats
	ability_id = str(st["ability"])
	ability_time = float(st["ability_dur"])
	ability_cd = float(st["ability_cd"])
	player.ability_invuln = ability_id == "dash" or ability_id == "ward" or ability_id == "phase"
	if ability_id == "freeze":
		world.set_freeze(true)
	AudioFX.play("ability")
	SaveData.report_event("abilities", 1)
	SaveData.data["abilities_used"] = int(SaveData.data["abilities_used"]) + 1
	hud.toast(str(st["ability_name"]), ABILITY_COLORS[ability_id])
	_refresh_aura()


func _end_ability() -> void:
	ability_time = 0.0
	if ability_id == "freeze":
		world.set_freeze(false)
	player.ability_invuln = false
	_refresh_aura()


# ------------------------------------------------------------------ world events
func _on_crystal(pos: Vector3) -> void:
	var gain: int = 2 if powerups.has("double") else 1
	crystals_run += gain
	SaveData.add_crystals(gain)
	SaveData.report_event("crystals", gain)
	AudioFX.play("crystal", 1.0 + randf() * 0.15)
	fx.burst(pos, Color("#4ac8ff"), 8)


func _on_powerup(kind: String, pos: Vector3) -> void:
	_activate_powerup(kind)
	SaveData.report_event("powerups", 1)
	SaveData.data["powerups_used"] = int(SaveData.data["powerups_used"]) + 1
	AudioFX.play("powerup")
	fx.burst(pos, Catalog.POWERUPS[kind]["color"], 14)
	hud.toast(str(Catalog.POWERUPS[kind]["name"]), Catalog.POWERUPS[kind]["color"])


func _on_hit(e: Entity, pos: Vector3) -> void:
	if state != "running":
		return
	if e.frozen:
		fx.burst(pos, Color("#9fe8ff"), 16)
		AudioFX.play("shatter")
		return
	var smash: bool = powerups.has("speed") or (ability_time > 0.0 and (ability_id == "dash" or ability_id == "ward"))
	if smash:
		fx.burst(pos, Color("#ffb04a"), 16)
		AudioFX.play("shatter")
		return
	if player.is_invulnerable():
		return
	if powerups.has("shield"):
		powerups.erase("shield")
		player.invuln = 0.6
		fx.burst(pos, Color("#4ad8ff"), 18)
		AudioFX.play("shatter")
		hud.toast("Shield broken!", Color("#4ad8ff"))
		_refresh_aura()
		return
	player.take_hit()
	AudioFX.play("hit")
	if e.enemy:
		AudioFX.play("enemy")
	cam_rig.add_shake(0.7)
	if bool(SaveData.get_setting("vibration")):
		Input.vibrate_handheld(120)
	fx.burst(pos, Color("#ff4060"), 14)
	hud.set_hp(player.hp, player.max_hp)
	if not player.alive:
		_game_over()


# ------------------------------------------------------------------ pause / game over
func pause_game() -> void:
	if state != "running":
		return
	state = "paused"
	get_tree().paused = true
	hud.show_pause(true)


func resume_game() -> void:
	if state != "paused":
		return
	state = "running"
	get_tree().paused = false
	hud.show_pause(false)


func _game_over() -> void:
	if state == "over":
		return
	state = "over"
	AudioFX.play("gameover")
	var score: int = int(distance) + crystals_run * 10
	var res: Dictionary = SaveData.finish_run(int(distance), crystals_run, run_time, score)
	var notices: Array = res["unlocks"]
	await get_tree().create_timer(1.0).timeout
	if not is_inside_tree():
		return
	hud.show_game_over({
		"new_best": res["new_best"], "score": score, "distance": int(distance),
		"crystals": crystals_run, "time": run_time,
		"best_score": SaveData.data["best_score"], "notices": notices,
	})
