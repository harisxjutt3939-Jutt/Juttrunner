class_name DungeonSection
extends Node3D
## One 24 m long modular dungeon segment. Decor variants are built lazily once and
## toggled on/off when the section is recycled (no per-recycle allocation).

const LENGTH := 24.0
const LANE_X: Array = [-2.2, 0.0, 2.2]

var entities: Array[Entity] = []
var current_variant: String = ""
var _variants: Dictionary = {}
var _walls: Node3D


func build_base(use_light: bool) -> void:
	Assets.add(self, Assets.box(Vector3(8.0, 0.5, LENGTH)), Assets.mat("floor"), Vector3(0, -0.25, 0))
	for x in [-1.1, 1.1]:
		Assets.add(self, Assets.box(Vector3(0.06, 0.02, LENGTH)), Assets.mat("glow_dim"), Vector3(x, 0.01, 0))
	Assets.add(self, Assets.box(Vector3(10.0, 0.6, LENGTH)), Assets.mat("dark"), Vector3(0, 6.8, 0))
	_walls = Node3D.new()
	add_child(_walls)
	for sx in [-1.0, 1.0]:
		Assets.add(_walls, Assets.box(Vector3(1.0, 7.0, LENGTH)), Assets.mat("wall"), Vector3(sx * 4.5, 3.0, 0))
		Assets.add(_walls, Assets.box(Vector3(0.06, 0.1, LENGTH)), Assets.mat("glow_dim"), Vector3(sx * 3.97, 1.0, 0))
	if use_light:
		var l := OmniLight3D.new()
		l.position = Vector3(0, 4.5, 0)
		l.omni_range = 18.0
		l.light_energy = 1.1
		l.light_color = Color("#8ab0ff")
		add_child(l)


func set_variant(vname: String) -> void:
	current_variant = vname
	if not _variants.has(vname):
		var g := Node3D.new()
		add_child(g)
		_variants[vname] = g
		match vname:
			"corridor":
				_v_corridor(g)
			"gate":
				_v_gate(g)
			"bridge":
				_v_bridge(g)
			"cave":
				_v_cave(g)
			"ruins":
				_v_ruins(g)
	for k in _variants.keys():
		(_variants[k] as Node3D).visible = (k == vname)
	_walls.visible = vname != "bridge"


func clear_entities(pool: NodePool) -> void:
	for e in entities:
		pool.release(e)
	entities.clear()


func add_entity(e: Entity, x: float, y: float, z: float) -> void:
	if e.get_parent() != null:
		e.get_parent().remove_child(e)
	add_child(e)
	e.position = Vector3(x, y, z)
	entities.append(e)


# ------------------------------------------------------------------ decor variants
func _v_corridor(g: Node3D) -> void:
	for z in [-9.0, 0.0, 9.0]:
		for sx in [-1.0, 1.0]:
			Assets.add(g, Assets.box(Vector3(0.9, 6.2, 0.9)), Assets.mat("stone_light"), Vector3(sx * 3.55, 3.0, z))
			Assets.add(g, Assets.box(Vector3(1.0, 0.12, 1.0)), Assets.mat("glow_dim"), Vector3(sx * 3.55, 4.6, z))
			Assets.add(g, Assets.sphere(0.13, 6), Assets.mat("fire"), Vector3(sx * 3.0, 2.4, z))
		Assets.add(g, Assets.box(Vector3(8.0, 0.5, 0.7)), Assets.mat("wall"), Vector3(0, 6.1, z))


func _v_gate(g: Node3D) -> void:
	for sx in [-1.0, 1.0]:
		Assets.add(g, Assets.box(Vector3(1.0, 6.4, 1.0)), Assets.mat("stone_light"), Vector3(sx * 3.3, 3.0, 0))
		Assets.add(g, Assets.box(Vector3(0.12, 2.4, 0.04)), Assets.mat("glow"), Vector3(sx * 3.3, 2.5, 0.52))
		Assets.add(g, Assets.box(Vector3(0.9, 0.9, 0.9)), Assets.mat("glow_dim"), Vector3(sx * 2.3, 3.9, 0))
	Assets.add(g, Assets.torus(2.0, 2.3), Assets.mat("glow"), Vector3(0, 3.9, 0), Vector3(90, 0, 0))
	Assets.add(g, Assets.quad(Vector2(4.1, 4.1)), Assets.mat("portal"), Vector3(0, 3.9, -0.1))


func _v_bridge(g: Node3D) -> void:
	Assets.add(g, Assets.box(Vector3(40.0, 0.1, LENGTH)), Assets.mat("void_glow"), Vector3(0, -4.0, 0))
	for sx in [-1.0, 1.0]:
		Assets.add(g, Assets.box(Vector3(0.14, 0.7, LENGTH)), Assets.mat("stone_light"), Vector3(sx * 3.85, 0.35, 0))
		Assets.add(g, Assets.box(Vector3(0.16, 0.06, LENGTH)), Assets.mat("glow"), Vector3(sx * 3.85, 0.73, 0))
		for z in [-8.0, 8.0]:
			Assets.add(g, Assets.box(Vector3(1.2, 10.0, 1.2)), Assets.mat("wall"), Vector3(sx * 6.5, -1.0, z))


func _v_cave(g: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("cave")
	for i in 9:
		var ln: float = rng.randf_range(1.2, 2.8)
		Assets.add(g, Assets.cylinder(0.35, 0.0, ln, 6), Assets.mat("stone_light"), Vector3(rng.randf_range(-3.5, 3.5), 6.5 - ln * 0.5, rng.randf_range(-11.0, 11.0)))
	for i in 6:
		var side: float = -1.0 if i % 2 == 0 else 1.0
		var r: float = rng.randf_range(0.6, 1.1)
		var b: MeshInstance3D = Assets.add(g, Assets.sphere(r, 8), Assets.mat("stone_light"), Vector3(side * rng.randf_range(3.3, 3.9), r * 0.4, rng.randf_range(-11.0, 11.0)))
		b.scale = Vector3(1.0, 0.8, 1.3)
	for i in 6:
		var side2: float = -1.0 if i % 2 == 0 else 1.0
		var mat: StandardMaterial3D = Assets.mat("crystal") if i % 3 != 0 else Assets.mat("crystal_violet")
		Assets.add(g, Assets.cylinder(0.0, 0.16, 1.0, 5), mat, Vector3(side2 * 3.6, 0.5, rng.randf_range(-11.0, 11.0)), Vector3(0, 0, side2 * -12.0))


func _v_ruins(g: Node3D) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash("ruins")
	for i in 6:
		var side: float = -1.0 if i % 2 == 0 else 1.0
		var h: float = rng.randf_range(1.5, 4.5)
		Assets.add(g, Assets.cylinder(0.35, 0.4, h, 8), Assets.mat("stone_light"), Vector3(side * 3.4, h * 0.5, -10.0 + i * 4.0))
	for i in 4:
		var side2: float = 1.0 if i % 2 == 0 else -1.0
		Assets.add(g, Assets.cylinder(0.3, 0.3, 1.6, 8), Assets.mat("stone_light"), Vector3(side2 * 3.3, 0.3, rng.randf_range(-10.0, 10.0)), Vector3(0, rng.randf_range(0, 90), 90))
		Assets.add(g, Assets.box(Vector3(0.7, 0.4, 0.7)), Assets.mat("wall"), Vector3(side2 * 3.5, 0.2, rng.randf_range(-10.0, 10.0)), Vector3(0, rng.randf_range(0, 90), 0))
	for sx in [-1.0, 1.0]:
		Assets.add(g, Assets.box(Vector3(0.03, 1.0, 0.4)), Assets.mat("glow"), Vector3(sx * 3.96, 2.4, -3.0))
		Assets.add(g, Assets.box(Vector3(0.03, 1.0, 0.4)), Assets.mat("glow"), Vector3(sx * 3.96, 2.4, 6.0))
