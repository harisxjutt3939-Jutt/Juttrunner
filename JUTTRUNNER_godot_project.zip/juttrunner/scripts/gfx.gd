class_name Gfx
extends RefCounted
## Graphics-quality presets. 0 = Low, 1 = Medium, 2 = High.


static func apply(vp: Viewport, q: int) -> void:
	vp.msaa_3d = Viewport.MSAA_2X if q >= 2 else Viewport.MSAA_DISABLED
	vp.scaling_3d_scale = 0.8 if q == 0 else 1.0


static func section_count(q: int) -> int:
	return 5 if q == 0 else 6


static func section_light(q: int, index: int) -> bool:
	if q >= 2:
		return true
	if q == 1:
		return index % 2 == 0
	return false


static func dust_amount(q: int) -> int:
	return [0, 24, 48][clampi(q, 0, 2)]


static func particle_scale(q: int) -> float:
	return [0.5, 0.8, 1.0][clampi(q, 0, 2)]
