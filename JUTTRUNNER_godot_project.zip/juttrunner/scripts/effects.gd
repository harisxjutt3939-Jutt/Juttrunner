extends Node3D
## Pooled one-shot particle bursts (crystal pickups, shattering obstacles, hits).

var speed: float = 0.0
var quality: int = 1
var _pool: Array = []
var _next: int = 0


func _ready() -> void:
	for i in 10:
		var p := CPUParticles3D.new()
		p.emitting = false
		p.one_shot = true
		p.amount = 12
		p.lifetime = 0.5
		p.explosiveness = 1.0
		p.direction = Vector3.UP
		p.spread = 180.0
		p.initial_velocity_min = 2.0
		p.initial_velocity_max = 5.0
		p.gravity = Vector3(0, -9, 0)
		p.local_coords = true
		p.mesh = Assets.box(Vector3(0.1, 0.1, 0.1))
		add_child(p)
		_pool.append(p)


func burst(pos: Vector3, color: Color, amount: int = 12) -> void:
	var p: CPUParticles3D = _pool[_next]
	_next = (_next + 1) % _pool.size()
	p.position = pos
	p.amount = maxi(int(float(amount) * Gfx.particle_scale(quality)), 4)
	p.material_override = Assets.colored(color, 2.5)
	p.restart()
	p.emitting = true


func _process(delta: float) -> void:
	for p in _pool:
		if (p as CPUParticles3D).emitting:
			p.position.z += speed * delta
