class_name HunterPreview
extends SubViewportContainer
## Self-contained 3D preview of a hunter (used in main menu, hunter selection and shop).

var spin: bool = true
var _vp: SubViewport
var _pivot: Node3D
var _model: HunterModel
var _pending: Array = []


func _ready() -> void:
	stretch = true
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_vp = SubViewport.new()
	_vp.own_world_3d = true
	_vp.transparent_bg = true
	_vp.msaa_3d = Viewport.MSAA_DISABLED
	_vp.size = Vector2i(512, 512)
	add_child(_vp)

	var env := Environment.new()
	env.background_mode = Environment.BG_CLEAR_COLOR
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("#8a95c8")
	env.ambient_light_energy = 0.9
	var we := WorldEnvironment.new()
	we.environment = env
	_vp.add_child(we)

	var cam := Camera3D.new()
	cam.fov = 38.0
	_vp.add_child(cam)
	cam.look_at_from_position(Vector3(0, 1.3, 5.2), Vector3(0, 1.0, 0))

	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-35, 30, 0)
	sun.light_energy = 1.2
	_vp.add_child(sun)
	var rim := OmniLight3D.new()
	rim.position = Vector3(-2.0, 2.5, -2.0)
	rim.light_color = Color("#8a5cff")
	rim.light_energy = 2.0
	rim.omni_range = 9.0
	_vp.add_child(rim)

	_pivot = Node3D.new()
	_vp.add_child(_pivot)
	_model = HunterModel.new()
	_pivot.add_child(_model)
	if not _pending.is_empty():
		show_hunter(_pending[0], _pending[1])


func show_hunter(hunter_id: String, skin_id: String, anim: String = "run") -> void:
	if _model == null:
		_pending = [hunter_id, skin_id]
		return
	_model.build(hunter_id, skin_id)
	_model.state = anim


func _process(delta: float) -> void:
	if spin and _pivot != null:
		_pivot.rotation.y += delta * 0.9
