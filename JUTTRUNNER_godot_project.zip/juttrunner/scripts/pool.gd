class_name NodePool
extends RefCounted
## Object pool for Entity nodes. Free entities live (hidden) under `holder`,
## so they are always owned by the scene tree and freed with the world (no leaks).

var holder: Node3D
var _free: Dictionary = {}


func _init(h: Node3D) -> void:
	holder = h


func acquire(kind: String) -> Entity:
	var list: Array = _free.get(kind, [])
	var e: Entity
	if list.is_empty():
		e = Entity.new()
		e.build(kind)
		holder.add_child(e)
	else:
		e = list.pop_back()
	e.reset_state()
	return e


func release(e: Entity) -> void:
	if e.get_parent() != null:
		e.get_parent().remove_child(e)
	holder.add_child(e)
	e.active = false
	if not _free.has(e.kind):
		_free[e.kind] = []
	(_free[e.kind] as Array).append(e)
