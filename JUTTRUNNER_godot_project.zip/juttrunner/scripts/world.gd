extends Node3D
## Endless dungeon generator. Sections scroll towards the camera and are recycled to the front;
## obstacles, crystals and power-ups come from an object pool. Also does all pickup/collision tests.

signal crystal_collected(world_pos: Vector3)
signal powerup_collected(kind: String, world_pos: Vector3)
signal obstacle_hit(entity: Entity, world_pos: Vector3)
signal enemy_near()

const SECTION_SCENE := preload("res://scenes/section.tscn")

var sections: Array[DungeonSection] = []
var pool: NodePool
var speed: float = 0.0
var difficulty: float = 0.0
var magnet_on: bool = false
var freeze_on: bool = false
var skip_obstacles: bool = false

var _theme: Dictionary = {}
var _time: float = 0.0


func setup(theme_id: String, quality: int) -> void:
	_theme = Catalog.THEMES[theme_id]
	Assets.apply_theme(theme_id)
	var holder := Node3D.new()
	holder.name = "PoolHolder"
	holder.visible = false
	add_child(holder)
	pool = NodePool.new(holder)
	var count: int = Gfx.section_count(quality)
	for i in count:
		var s: DungeonSection = SECTION_SCENE.instantiate()
		add_child(s)
		s.build_base(Gfx.section_light(quality, i))
		s.position = Vector3(0, 0, 12.0 - DungeonSection.LENGTH * i)
		sections.append(s)
		_pick_variant(s)
		_populate(s, 0 if i == 0 else (1 if i == 1 else 2))


func _pick_variant(s: DungeonSection) -> void:
	var list: Array = _theme["variants"]
	s.set_variant(list[randi() % list.size()])


func set_freeze(on: bool) -> void:
	freeze_on = on
	for s in sections:
		for e in s.entities:
			if e.category == "obstacle":
				e.set_frozen(on)


# ------------------------------------------------------------------ per frame
func update_world(delta: float, spd: float, p_x: float, p_y0: float, p_y1: float) -> void:
	speed = spd
	_time += delta
	var dz: float = spd * delta
	for s in sections:
		s.position.z += dz
	for s in sections:
		if s.position.z - DungeonSection.LENGTH * 0.5 > 14.0:
			var min_z: float = 1.0e9
			for q in sections:
				min_z = minf(min_z, q.position.z)
			s.position.z = min_z - DungeonSection.LENGTH
			_pick_variant(s)
			_populate(s, 2)
	_update_entities(delta, p_x, p_y0, p_y1)


func _update_entities(delta: float, p_x: float, p_y0: float, p_y1: float) -> void:
	for sec in sections:
		var sz: float = sec.position.z
		if sz < -85.0:
			continue
		for e in sec.entities:
			if not e.active:
				continue
			if e.approach != 0.0 and not e.frozen:
				e.position.z += e.approach * delta
			e.animate(_time, delta)
			var ez: float = sz + e.position.z
			if e.enemy and not e.alerted and ez > -24.0:
				e.alerted = true
				enemy_near.emit()
			if ez < -14.0 or ez > 5.0:
				continue
			if magnet_on and e.category == "crystal" and ez < 3.0:
				var cur := Vector3(e.position.x, e.position.y, ez)
				var nxt: Vector3 = cur.move_toward(Vector3(p_x, p_y0 + 0.9, 0.0), (speed + 12.0) * delta)
				e.position = Vector3(nxt.x, nxt.y, nxt.z - sz)
				ez = nxt.z
			if absf(ez) > e.half_z + 0.4:
				continue
			if absf(e.position.x - p_x) > e.half_x + 0.4:
				continue
			if p_y0 >= e.position.y + e.y1 or p_y1 <= e.position.y + e.y0:
				continue
			var gpos := Vector3(e.position.x, e.position.y + (e.y0 + e.y1) * 0.5, ez)
			if e.category == "crystal":
				e.active = false
				e.visible = false
				crystal_collected.emit(gpos)
			elif e.category == "powerup":
				e.active = false
				e.visible = false
				powerup_collected.emit(e.pu_kind, gpos)
			else:
				if skip_obstacles:
					continue
				e.active = false
				e.visible = false
				obstacle_hit.emit(e, gpos)


# ------------------------------------------------------------------ generation
func _pick(weights: Array) -> int:
	var total: float = 0.0
	for w in weights:
		total += float(w)
	var r: float = randf() * total
	for i in weights.size():
		r -= float(weights[i])
		if r <= 0.0:
			return i
	return weights.size() - 1


func _populate(sec: DungeonSection, level: int) -> void:
	sec.clear_entities(pool)
	if level == 0:
		return
	var occ: Array = []
	var singles: Array = []
	if level >= 2 and randf() > 0.12:
		var rows: Array = [-6.0, 6.0] if speed < 17.0 else [-5.0]
		for z in rows:
			_make_row(sec, float(z), occ, singles)
	_make_crystals(sec, occ, singles)
	if level >= 2 and randf() < 0.14:
		_make_powerup(sec, occ)


func _spawn(sec: DungeonSection, kind: String, lane: int, z: float, occ: Array) -> void:
	var e: Entity = pool.acquire(kind)
	if freeze_on:
		e.set_frozen(true)
	sec.add_entity(e, float(DungeonSection.LANE_X[lane]), 0.0, z)
	occ.append([lane, z])


func _make_row(sec: DungeonSection, z: float, occ: Array, singles: Array) -> void:
	var d: float = difficulty
	var w: Array = [3.0, 2.0, 0.6 + 3.0 * d, 0.0, 0.0, 0.0]
	if d > 0.08:
		w[3] = 0.4 + d
		w[4] = 0.3 + d
	if d > 0.2:
		w[5] = d * 1.2
	var lanes: Array = [0, 1, 2]
	lanes.shuffle()
	match _pick(w):
		0:
			var kinds: Array = ["block", "spikes"]
			if d > 0.12:
				kinds.append("beast")
			_spawn(sec, kinds[randi() % kinds.size()], lanes[0], z, occ)
			singles.append([lanes[0], z])
		1:
			var k1: String = "beam"
			if d > 0.18 and randf() < 0.5:
				k1 = "shadow"
			var n1: int = 2 if randf() < d else 1
			for i in n1:
				_spawn(sec, k1, lanes[i], z, occ)
		2:
			var k2: String = "wall"
			if d > 0.1 and randf() < 0.5:
				k2 = "skeleton"
			_spawn(sec, k2, lanes[0], z, occ)
			_spawn(sec, k2 if randf() < 0.4 else "wall", lanes[1], z, occ)
		3:
			var k4: String = "spikes" if randf() < 0.5 else "block"
			for l in 3:
				_spawn(sec, k4, l, z, occ)
		4:
			for l in 3:
				_spawn(sec, "beam", l, z, occ)
		5:
			_spawn(sec, "wall", lanes[0], z, occ)
			_spawn(sec, "beam", lanes[1], z, occ)
			_spawn(sec, "spikes", lanes[2], z, occ)


func _is_free(occ: Array, lane: int, z: float, margin: float) -> bool:
	for o in occ:
		if int(o[0]) == lane and absf(float(o[1]) - z) < margin:
			return false
	return true


func _spawn_crystal(sec: DungeonSection, lane: int, z: float, y: float) -> void:
	var e: Entity = pool.acquire("crystal")
	sec.add_entity(e, float(DungeonSection.LANE_X[lane]), y, z)


func _make_crystals(sec: DungeonSection, occ: Array, singles: Array) -> void:
	if not singles.is_empty() and randf() < 0.6:
		var s: Array = singles[randi() % singles.size()]
		var ys: Array = [0.9, 1.6, 2.0, 1.6, 0.9]
		for i in 5:
			_spawn_crystal(sec, int(s[0]), float(s[1]) + (i - 2) * 1.6, float(ys[i]))
	var lane2: int = randi() % 3
	var n: int = randi_range(5, 8)
	var z0: float = randf_range(-11.0, 11.0 - n * 1.6)
	for i in n:
		var zc: float = z0 + i * 1.6
		if _is_free(occ, lane2, zc, 1.8):
			_spawn_crystal(sec, lane2, zc, 0.8)


func _make_powerup(sec: DungeonSection, occ: Array) -> void:
	var lane: int = randi() % 3
	var z: float = randf_range(-9.0, 9.0)
	if not _is_free(occ, lane, z, 2.5):
		return
	var kinds: Array = ["magnet", "shield", "speed", "double"]
	var k: String = kinds[_pick([3.0, 3.0, 2.0, 3.0])]
	var e: Entity = pool.acquire("pu_" + k)
	sec.add_entity(e, float(DungeonSection.LANE_X[lane]), 1.0, z)
