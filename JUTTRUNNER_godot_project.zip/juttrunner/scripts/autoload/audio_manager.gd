extends Node
## Procedural placeholder audio: every sound/music loop is synthesised at startup,
## so the project ships without binary audio files. Replace `sounds[...]` with real
## AudioStream resources later (load("your audio file")) without touching gameplay code.

const SR := 22050
const VOICES := 10

var sounds: Dictionary = {}
var generated: bool = false
var _players: Array = []
var _next: int = 0
var _music: AudioStreamPlayer
var _ambience: AudioStreamPlayer


func _init() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS


func _ready() -> void:
	for bus_name in ["Music", "SFX"]:
		if AudioServer.get_bus_index(bus_name) == -1:
			AudioServer.add_bus()
			var idx: int = AudioServer.bus_count - 1
			AudioServer.set_bus_name(idx, bus_name)
			AudioServer.set_bus_send(idx, "Master")
	for i in VOICES:
		var p := AudioStreamPlayer.new()
		p.bus = "SFX"
		add_child(p)
		_players.append(p)
	_music = AudioStreamPlayer.new()
	_music.bus = "Music"
	_music.volume_db = -4.0
	add_child(_music)
	_ambience = AudioStreamPlayer.new()
	_ambience.bus = "SFX"
	_ambience.volume_db = -16.0
	add_child(_ambience)
	apply_settings()


func apply_settings() -> void:
	_set_bus("SFX", float(SaveData.get_setting("sound")))
	_set_bus("Music", float(SaveData.get_setting("music")))


func _set_bus(bus_name: String, linear: float) -> void:
	var idx: int = AudioServer.get_bus_index(bus_name)
	if idx < 0:
		return
	AudioServer.set_bus_mute(idx, linear <= 0.001)
	AudioServer.set_bus_volume_db(idx, linear_to_db(maxf(linear, 0.001)))


func play(sound_name: String, pitch: float = 1.0, volume_db: float = 0.0) -> void:
	if not sounds.has(sound_name):
		return
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % VOICES
	p.stream = sounds[sound_name]
	p.pitch_scale = pitch
	p.volume_db = volume_db
	p.play()


func play_music() -> void:
	if sounds.has("music") and not _music.playing:
		_music.stream = sounds["music"]
		_music.play()


func play_ambience() -> void:
	if sounds.has("ambience") and not _ambience.playing:
		_ambience.stream = sounds["ambience"]
		_ambience.play()


func stop_all_loops() -> void:
	_music.stop()
	_ambience.stop()


# ------------------------------------------------------------------ generation
func generate_all() -> void:
	if generated:
		return
	sounds["crystal"] = _snd_crystal()
	sounds["jump"] = _make(_tone(260.0, 620.0, 0.22, SR, 3, 0.5), SR)
	sounds["slide"] = _make(_tone(260.0, 90.0, 0.35, SR, 0, 0.55, 0.01, 0.9), SR)
	sounds["lane"] = _make(_tone(520.0, 380.0, 0.07, SR, 3, 0.25), SR)
	sounds["ui"] = _make(_tone(620.0, 900.0, 0.07, SR, 3, 0.35), SR)
	sounds["error"] = _make(_tone(160.0, 110.0, 0.25, SR, 1, 0.3), SR)
	await get_tree().process_frame
	sounds["hit"] = _make(_tone(150.0, 40.0, 0.4, SR, 2, 0.8, 0.002, 0.5), SR)
	sounds["shatter"] = _make(_tone(900.0, 200.0, 0.25, SR, 0, 0.6, 0.001, 0.9), SR)
	sounds["gameover"] = _make(_tone(420.0, 70.0, 0.9, SR, 3, 0.6), SR)
	sounds["enemy"] = _snd_enemy()
	await get_tree().process_frame
	sounds["powerup"] = _make(_arp([440.0, 554.0, 659.0, 880.0], 0.08, 0, 0.45), SR)
	sounds["milestone"] = _make(_arp([523.0, 659.0, 784.0, 1046.0, 1318.0], 0.09, 3, 0.45), SR)
	sounds["buy"] = _make(_arp([784.0, 988.0, 1318.0], 0.07, 0, 0.45), SR)
	sounds["ability"] = _snd_ability()
	await get_tree().process_frame
	sounds["ambience"] = _snd_ambience()
	await get_tree().process_frame
	sounds["music"] = _snd_music()
	generated = true


func _snd_crystal() -> AudioStreamWAV:
	var out := PackedFloat32Array()
	out.resize(int(0.3 * SR))
	out = _mix(out, _tone(988.0, 1319.0, 0.12, SR, 0, 0.5), 0)
	out = _mix(out, _tone(1319.0, 1760.0, 0.18, SR, 0, 0.5), int(0.07 * SR))
	return _make(out, SR)


func _snd_enemy() -> AudioStreamWAV:
	var s: PackedFloat32Array = _tone(110.0, 55.0, 0.6, SR, 2, 0.6, 0.01, 0.15)
	for i in s.size():
		s[i] *= 0.6 + 0.4 * sin(float(i) / float(SR) * TAU * 28.0)
	return _make(s, SR)


func _snd_ability() -> AudioStreamWAV:
	var out := PackedFloat32Array()
	out.resize(int(0.6 * SR))
	out = _mix(out, _tone(200.0, 1200.0, 0.55, SR, 2, 0.25), 0)
	out = _mix(out, _tone(400.0, 2400.0, 0.5, SR, 0, 0.25), 0)
	return _make(out, SR)


func _snd_ambience() -> AudioStreamWAV:
	var rate: int = 11025
	var n: int = rate * 4
	var out := PackedFloat32Array()
	out.resize(n)
	var lp: float = 0.0
	for i in n:
		var t: float = float(i) / float(rate)
		var drone: float = sin(TAU * 55.0 * t) * 0.35 + sin(TAU * 55.5 * t) * 0.25 + sin(TAU * 82.5 * t) * 0.08
		lp += ((randf() * 2.0 - 1.0) - lp) * 0.04
		out[i] = (drone + lp * 0.5) * 0.5
	return _make(out, rate, true)


func _snd_music() -> AudioStreamWAV:
	var rate: int = 11025
	var bar: float = 1.6
	var chords: Array = [
		[110.0, 130.81, 164.81],
		[87.31, 110.0, 130.81],
		[73.42, 87.31, 110.0],
		[82.41, 103.83, 123.47],
	]
	var pattern: Array = [0, 1, 2, 1, 2, 1, 0, 2]
	var total: int = int(bar * 4.0 * rate)
	var out := PackedFloat32Array()
	out.resize(total)
	for b in 4:
		var ch: Array = chords[b]
		var t0: int = int(float(b) * bar * rate)
		out = _mix(out, _tone(ch[0], ch[0], bar, rate, 0, 0.30), t0)
		out = _mix(out, _tone(ch[0] * 2.0, ch[0] * 2.0, bar, rate, 3, 0.10), t0)
		for k in 8:
			var f: float = float(ch[pattern[k]]) * 4.0
			out = _mix(out, _tone(f, f, 0.3, rate, 3, 0.09), t0 + int(float(k) * 0.2 * rate))
	return _make(out, rate, true)


# ------------------------------------------------------------------ synth helpers
func _osc(wave: int, phase: float) -> float:
	var p: float = phase - floor(phase)
	match wave:
		0:
			return sin(p * TAU)
		1:
			return 1.0 if p < 0.5 else -1.0
		2:
			return 2.0 * p - 1.0
		3:
			return 4.0 * absf(p - 0.5) - 1.0
	return 0.0


func _tone(f0: float, f1: float, dur: float, rate: int, wave: int, vol: float, attack: float = 0.005, noise: float = 0.0) -> PackedFloat32Array:
	var n: int = int(dur * rate)
	var out := PackedFloat32Array()
	out.resize(n)
	var phase: float = 0.0
	for i in n:
		var t: float = float(i) / float(n)
		phase += lerpf(f0, f1, t) / float(rate)
		var env: float = minf(1.0, (float(i) / float(rate)) / attack) * pow(1.0 - t, 2.0)
		var s: float = _osc(wave, phase) * (1.0 - noise) + (randf() * 2.0 - 1.0) * noise
		out[i] = s * env * vol
	return out


func _arp(freqs: Array, note_len: float, wave: int, vol: float) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	out.resize(int((note_len * freqs.size() + note_len * 2.0) * SR))
	for i in freqs.size():
		var f: float = float(freqs[i])
		out = _mix(out, _tone(f, f, note_len * 2.0, SR, wave, vol), int(float(i) * note_len * SR))
	return out


func _mix(dst: PackedFloat32Array, src: PackedFloat32Array, offset: int) -> PackedFloat32Array:
	for i in src.size():
		var j: int = offset + i
		if j >= dst.size():
			break
		dst[j] += src[i]
	return dst


func _make(samples: PackedFloat32Array, rate: int, loop: bool = false) -> AudioStreamWAV:
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = rate
	w.stereo = false
	var bytes := PackedByteArray()
	bytes.resize(samples.size() * 2)
	for i in samples.size():
		bytes.encode_s16(i * 2, int(clampf(samples[i], -1.0, 1.0) * 30000.0))
	w.data = bytes
	if loop:
		w.loop_mode = AudioStreamWAV.LOOP_FORWARD
		w.loop_begin = 0
		w.loop_end = samples.size()
	return w
