extends Node
## Persistent player data stored in user://. store_var keeps ints as ints.

signal crystals_changed(value: int)
signal unlocked(kind: String, id: String)

const SAVE_FILE := "user://juttrunner_save.dat"
const TMP_FILE := "user://juttrunner_save.tmp"
const BUY_OK := 0
const BUY_ALREADY := 1
const BUY_NOT_ENOUGH := 2

var data: Dictionary = {}


func _init() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	data = _defaults()


func _ready() -> void:
	load_game()
	ensure_missions()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST \
			or what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_WINDOW_FOCUS_OUT:
		save_game()


func _defaults() -> Dictionary:
	return {
		"crystals": 0,
		"best_distance": 0,
		"best_score": 0,
		"best_time": 0.0,
		"total_distance": 0.0,
		"total_crystals": 0,
		"runs": 0,
		"powerups_used": 0,
		"abilities_used": 0,
		"owned_hunters": ["shadow"],
		"owned_skins": [],
		"owned_trails": ["none"],
		"owned_themes": ["catacombs"],
		"boosts": {"magnet": 0, "shield": 0, "speed": 0, "double": 0},
		"hunter": "shadow",
		"skins": {},
		"trail": "none",
		"theme": "catacombs",
		"settings": {"sound": 1.0, "music": 0.7, "quality": 1, "controls": 2, "vibration": true},
		"missions": [],
		"achievements_claimed": [],
	}


# ---------------------------------------------------------------- load / save
func load_game() -> void:
	var d: Dictionary = _defaults()
	var path: String = ""
	if FileAccess.file_exists(SAVE_FILE):
		path = SAVE_FILE
	elif FileAccess.file_exists(TMP_FILE):
		path = TMP_FILE
	if path != "":
		var f := FileAccess.open(path, FileAccess.READ)
		if f != null:
			var loaded: Variant = f.get_var()
			f.close()
			if typeof(loaded) == TYPE_DICTIONARY:
				_merge(d, loaded)
	data = d


func _merge(dst: Dictionary, src: Dictionary) -> void:
	for key in src.keys():
		if not dst.has(key):
			continue
		if typeof(dst[key]) == TYPE_DICTIONARY and typeof(src[key]) == TYPE_DICTIONARY:
			_merge(dst[key], src[key])
		elif typeof(dst[key]) == typeof(src[key]):
			dst[key] = src[key]


func save_game() -> void:
	var f := FileAccess.open(TMP_FILE, FileAccess.WRITE)
	if f == null:
		push_warning("JUTTRUNNER: cannot write save file")
		return
	f.store_var(data)
	f.close()
	var dir := DirAccess.open("user://")
	if dir != null:
		if dir.file_exists("juttrunner_save.dat"):
			dir.remove("juttrunner_save.dat")
		dir.rename("juttrunner_save.tmp", "juttrunner_save.dat")


func reset_all() -> void:
	data = _defaults()
	ensure_missions()
	save_game()
	crystals_changed.emit(0)


# ---------------------------------------------------------------- settings
func get_setting(key: String) -> Variant:
	return (data["settings"] as Dictionary).get(key)


func set_setting(key: String, value: Variant) -> void:
	(data["settings"] as Dictionary)[key] = value
	save_game()


# ---------------------------------------------------------------- currency
func crystals() -> int:
	return int(data["crystals"])


func add_crystals(n: int) -> void:
	data["crystals"] = int(data["crystals"]) + n
	crystals_changed.emit(int(data["crystals"]))


func spend(n: int) -> bool:
	if int(data["crystals"]) < n:
		return false
	data["crystals"] = int(data["crystals"]) - n
	crystals_changed.emit(int(data["crystals"]))
	save_game()
	return true


# ---------------------------------------------------------------- ownership
func owns(kind: String, id: String) -> bool:
	if kind == "skins" and id.ends_with("_default"):
		return true
	return (data["owned_" + kind] as Array).has(id)


func buy(kind: String, id: String, price: int) -> int:
	if owns(kind, id):
		return BUY_ALREADY
	if not spend(price):
		return BUY_NOT_ENOUGH
	(data["owned_" + kind] as Array).append(id)
	save_game()
	return BUY_OK


func buy_boost(id: String, price: int) -> int:
	if not spend(price):
		return BUY_NOT_ENOUGH
	var b: Dictionary = data["boosts"]
	b[id] = int(b.get(id, 0)) + 1
	save_game()
	return BUY_OK


func consume_boosts() -> Array:
	var used: Array = []
	var b: Dictionary = data["boosts"]
	for id in b.keys():
		if int(b[id]) > 0:
			b[id] = int(b[id]) - 1
			used.append(id)
	if not used.is_empty():
		save_game()
	return used


func equip(kind: String, id: String) -> void:
	match kind:
		"hunters":
			data["hunter"] = id
		"trails":
			data["trail"] = id
		"themes":
			data["theme"] = id
		"skins":
			var hid: String = Catalog.SKINS[id]["hunter"]
			(data["skins"] as Dictionary)[hid] = id
	save_game()


func get_skin(hunter_id: String) -> String:
	return str((data["skins"] as Dictionary).get(hunter_id, hunter_id + "_default"))


func check_progress_unlocks() -> Array:
	var out: Array = []
	var best: int = int(data["best_distance"])
	for h in Catalog.HUNTER_ORDER:
		var hd: Dictionary = Catalog.HUNTERS[h]
		var req: int = int(hd["unlock_distance"])
		if req > 0 and best >= req and not owns("hunters", h):
			(data["owned_hunters"] as Array).append(h)
			out.append("Hunter unlocked: " + str(hd["name"]))
			unlocked.emit("hunters", h)
	for t in Catalog.THEME_ORDER:
		var td: Dictionary = Catalog.THEMES[t]
		var req2: int = int(td["unlock_distance"])
		if req2 > 0 and best >= req2 and not owns("themes", t):
			(data["owned_themes"] as Array).append(t)
			out.append("Dungeon unlocked: " + str(td["name"]))
			unlocked.emit("themes", t)
	return out


# ---------------------------------------------------------------- run results
func finish_run(distance: int, crystals_run: int, time_s: float, score: int) -> Dictionary:
	var res: Dictionary = {"new_best": false, "unlocks": []}
	data["runs"] = int(data["runs"]) + 1
	data["total_distance"] = float(data["total_distance"]) + float(distance)
	data["total_crystals"] = int(data["total_crystals"]) + crystals_run
	if score > int(data["best_score"]):
		data["best_score"] = score
		res["new_best"] = true
	if distance > int(data["best_distance"]):
		data["best_distance"] = distance
	if time_s > float(data["best_time"]):
		data["best_time"] = time_s
	report_event("runs", 1)
	report_max("run_distance", distance)
	res["unlocks"] = check_progress_unlocks()
	save_game()
	return res


# ---------------------------------------------------------------- missions
func _new_mission(exclude: Array) -> Dictionary:
	var candidates: Array = []
	for tpl in Catalog.MISSION_TEMPLATES:
		if not exclude.has(tpl["event"]):
			candidates.append(tpl)
	if candidates.is_empty():
		candidates = Catalog.MISSION_TEMPLATES
	var chosen: Dictionary = candidates[randi() % candidates.size()]
	var tier: int = randi() % (chosen["targets"] as Array).size()
	var target: int = int(chosen["targets"][tier])
	return {
		"event": chosen["event"],
		"text": str(chosen["text"]) % target,
		"target": target,
		"reward": int(chosen["rewards"][tier]),
		"progress": 0,
	}


func ensure_missions() -> void:
	var ms: Array = data["missions"]
	while ms.size() < 3:
		var ex: Array = []
		for m in ms:
			ex.append(m["event"])
		ms.append(_new_mission(ex))


func report_event(event: String, amount: int = 1) -> void:
	for m in (data["missions"] as Array):
		if m["event"] == event:
			m["progress"] = mini(int(m["target"]), int(m["progress"]) + amount)


func report_max(event: String, value: int) -> void:
	for m in (data["missions"] as Array):
		if m["event"] == event:
			m["progress"] = mini(int(m["target"]), maxi(int(m["progress"]), value))


func mission_done(i: int) -> bool:
	var m: Dictionary = (data["missions"] as Array)[i]
	return int(m["progress"]) >= int(m["target"])


func claim_mission(i: int) -> int:
	if not mission_done(i):
		return 0
	var ms: Array = data["missions"]
	var reward: int = int(ms[i]["reward"])
	add_crystals(reward)
	var ex: Array = []
	for j in ms.size():
		if j != i:
			ex.append(ms[j]["event"])
	ms[i] = _new_mission(ex)
	save_game()
	return reward


# ---------------------------------------------------------------- achievements
func stat(key: String) -> float:
	if key == "hunters_owned":
		return float((data["owned_hunters"] as Array).size())
	return float(data.get(key, 0))


func ach_done(a: Dictionary) -> bool:
	return stat(a["stat"]) >= float(a["target"])


func ach_claimed(a: Dictionary) -> bool:
	return (data["achievements_claimed"] as Array).has(a["id"])


func claim_achievement(a: Dictionary) -> int:
	if not ach_done(a) or ach_claimed(a):
		return 0
	(data["achievements_claimed"] as Array).append(a["id"])
	add_crystals(int(a["reward"]))
	save_game()
	return int(a["reward"])
