extends Node
## Static game data: hunters, skins, trails, dungeon themes, power-ups, missions, achievements.

const HUNTER_ORDER: Array = ["shadow", "blade", "ice", "flame", "phantom"]
const THEME_ORDER: Array = ["catacombs", "caverns", "ruins", "abyss", "ember"]
const TRAIL_ORDER: Array = ["none", "blue", "violet", "ember", "gold", "ghost"]
const BOOST_ORDER: Array = ["magnet", "shield", "speed", "double"]

var HUNTERS: Dictionary = {}
var SKINS: Dictionary = {}
var TRAILS: Dictionary = {}
var THEMES: Dictionary = {}
var POWERUPS: Dictionary = {}
var BOOST_PRICES: Dictionary = {"magnet": 60, "shield": 60, "speed": 80, "double": 80}
var MISSION_TEMPLATES: Array = []
var ACHIEVEMENTS: Array = []
# [distance in one run, crystal reward]
var MILESTONES: Array = [[250, 10], [500, 20], [1000, 40], [2000, 80], [3500, 120], [5000, 200], [8000, 300]]


func _init() -> void:
	_build_hunters()
	_build_skins()
	_build_trails()
	_build_themes()
	_build_powerups()
	_build_missions()


func _build_hunters() -> void:
	HUNTERS = {
		"shadow": {
			"name": "Shadow Hunter", "title": "Balanced Scout",
			"desc": "Fast, agile and reliable. The perfect first hunter.",
			"price": 0, "unlock_distance": 0,
			"speed": 1.0, "lane_speed": 14.0, "jump": 10.0, "hp": 2,
			"stats": {"speed": 3, "agility": 4, "health": 2},
			"ability": "slow", "ability_name": "Shadow Focus",
			"ability_desc": "Slows the dungeon for 3.5 s so you can read the path.",
			"ability_cd": 22.0, "ability_dur": 3.5,
			"color": Color("#1b1f3b"), "accent": Color("#7a5cff"), "hair": Color("#0b0b14"),
		},
		"blade": {
			"name": "Blade Hunter", "title": "Dash Specialist",
			"desc": "A swordsman who bursts through danger.",
			"price": 400, "unlock_distance": 1000,
			"speed": 1.05, "lane_speed": 13.0, "jump": 10.0, "hp": 2,
			"stats": {"speed": 4, "agility": 3, "health": 2},
			"ability": "dash", "ability_name": "Blade Dash",
			"ability_desc": "Dash forward at double speed for 1.4 s, smashing everything.",
			"ability_cd": 20.0, "ability_dur": 1.4,
			"color": Color("#2a1a1a"), "accent": Color("#ff4a5a"), "hair": Color("#d8d8e8"),
		},
		"ice": {
			"name": "Ice Hunter", "title": "Frost Mage",
			"desc": "Freezes the dungeon itself.",
			"price": 700, "unlock_distance": 2500,
			"speed": 0.98, "lane_speed": 14.0, "jump": 10.0, "hp": 2,
			"stats": {"speed": 3, "agility": 3, "health": 2},
			"ability": "freeze", "ability_name": "Frost Lock",
			"ability_desc": "Freezes obstacles for 4 s. Frozen obstacles shatter harmlessly.",
			"ability_cd": 26.0, "ability_dur": 4.0,
			"color": Color("#1a2c44"), "accent": Color("#7fe0ff"), "hair": Color("#dff6ff"),
		},
		"flame": {
			"name": "Flame Hunter", "title": "Ember Guardian",
			"desc": "Tough and fiery, with an extra heart.",
			"price": 900, "unlock_distance": 4000,
			"speed": 0.95, "lane_speed": 12.5, "jump": 9.8, "hp": 3,
			"stats": {"speed": 2, "agility": 2, "health": 4},
			"ability": "ward", "ability_name": "Fire Ward",
			"ability_desc": "Immune to damage for 6 s and burn obstacles away.",
			"ability_cd": 28.0, "ability_dur": 6.0,
			"color": Color("#3a1a10"), "accent": Color("#ff8a2a"), "hair": Color("#ff6a1a"),
		},
		"phantom": {
			"name": "Phantom Hunter", "title": "Void Walker",
			"desc": "The fastest hunter. Slips between worlds.",
			"price": 1500, "unlock_distance": 6000,
			"speed": 1.08, "lane_speed": 16.0, "jump": 10.5, "hp": 2,
			"stats": {"speed": 5, "agility": 5, "health": 2},
			"ability": "phase", "ability_name": "Phase Shift",
			"ability_desc": "Pass through obstacles for 3 s.",
			"ability_cd": 24.0, "ability_dur": 3.0,
			"color": Color("#16101f"), "accent": Color("#cfd6ff"), "hair": Color("#0a0a12"),
		},
	}


func _build_skins() -> void:
	SKINS = {}
	for h in HUNTER_ORDER:
		var hd: Dictionary = HUNTERS[h]
		SKINS[h + "_default"] = {"hunter": h, "name": "Default", "price": 0, "color": hd["color"], "accent": hd["accent"]}
		SKINS[h + "_royal"] = {"hunter": h, "name": "Royal Gold", "price": 250, "color": Color("#2b2210"), "accent": Color("#ffcf4a")}
		SKINS[h + "_void"] = {"hunter": h, "name": "Void Violet", "price": 350, "color": Color("#1a0a2e"), "accent": Color("#d04bff")}


func _build_trails() -> void:
	TRAILS = {
		"none": {"name": "No Trail", "price": 0, "color": Color.BLACK},
		"blue": {"name": "Mana Stream", "price": 150, "color": Color("#3aa8ff")},
		"violet": {"name": "Void Sparks", "price": 200, "color": Color("#a05aff")},
		"ember": {"name": "Ember Wake", "price": 250, "color": Color("#ff8a2a")},
		"gold": {"name": "Royal Dust", "price": 400, "color": Color("#ffd24a")},
		"ghost": {"name": "Ghost Mist", "price": 500, "color": Color("#cfe4ff")},
	}


func _build_themes() -> void:
	THEMES = {
		"catacombs": {
			"name": "Stone Catacombs", "price": 0, "unlock_distance": 0,
			"desc": "Cold stone corridors lit by blue mana.",
			"wall": Color("#3a3d4a"), "floor": Color("#2a2c36"), "fog": Color("#080a16"),
			"ambient": Color("#35406a"), "glow": Color("#4aa8ff"), "light": Color("#6fa8ff"),
			"variants": ["corridor", "gate", "ruins", "corridor"],
		},
		"caverns": {
			"name": "Crystal Caverns", "price": 350, "unlock_distance": 2000,
			"desc": "Natural caves bursting with violet crystals.",
			"wall": Color("#2b2650"), "floor": Color("#1d1a3a"), "fog": Color("#0a0618"),
			"ambient": Color("#40306e"), "glow": Color("#b05aff"), "light": Color("#b58aff"),
			"variants": ["cave", "cave", "corridor", "bridge"],
		},
		"ruins": {
			"name": "Ancient Ruins", "price": 600, "unlock_distance": 3500,
			"desc": "Crumbling halls of a forgotten guild.",
			"wall": Color("#5a5446"), "floor": Color("#3a362c"), "fog": Color("#0c0d0a"),
			"ambient": Color("#5a6a58"), "glow": Color("#3de0c0"), "light": Color("#7de8c8"),
			"variants": ["ruins", "gate", "ruins", "corridor"],
		},
		"abyss": {
			"name": "Shadow Abyss", "price": 900, "unlock_distance": 5000,
			"desc": "Bridges over a bottomless void.",
			"wall": Color("#15101f"), "floor": Color("#0e0a16"), "fog": Color("#05030a"),
			"ambient": Color("#2a1850"), "glow": Color("#a040ff"), "light": Color("#9a60ff"),
			"variants": ["bridge", "bridge", "gate", "cave"],
		},
		"ember": {
			"name": "Ember Depths", "price": 1200, "unlock_distance": 8000,
			"desc": "Heat, ash and glowing rock.",
			"wall": Color("#4a2a24"), "floor": Color("#2e1a16"), "fog": Color("#120604"),
			"ambient": Color("#7a3a2a"), "glow": Color("#ff7a3a"), "light": Color("#ff9a5a"),
			"variants": ["cave", "bridge", "ruins", "gate"],
		},
	}


func _build_powerups() -> void:
	POWERUPS = {
		"magnet": {"name": "Mana Magnet", "dur": 10.0, "color": Color("#ff4a6a"), "desc": "Pulls in nearby crystals for 10 s."},
		"shield": {"name": "Shield", "dur": 12.0, "color": Color("#4ad8ff"), "desc": "Blocks one hit, or lasts 12 s."},
		"speed": {"name": "Speed Burst", "dur": 5.0, "color": Color("#ffd84a"), "desc": "+50% speed and smash obstacles for 5 s."},
		"double": {"name": "Double Mana", "dur": 12.0, "color": Color("#c24aff"), "desc": "Crystals count double for 12 s."},
	}


func _build_missions() -> void:
	MISSION_TEMPLATES = [
		{"event": "crystals", "text": "Collect %d Mana Crystals", "targets": [40, 80, 150], "rewards": [30, 60, 110]},
		{"event": "run_distance", "text": "Run %d m in a single run", "targets": [300, 600, 1200], "rewards": [40, 80, 160]},
		{"event": "runs", "text": "Complete %d runs", "targets": [2, 4, 6], "rewards": [25, 50, 80]},
		{"event": "powerups", "text": "Collect %d power-ups", "targets": [2, 4, 7], "rewards": [30, 60, 100]},
		{"event": "jumps", "text": "Jump %d times", "targets": [15, 40, 80], "rewards": [20, 40, 70]},
		{"event": "slides", "text": "Slide %d times", "targets": [10, 30, 60], "rewards": [20, 40, 70]},
		{"event": "abilities", "text": "Use your hunter ability %d times", "targets": [1, 3, 5], "rewards": [30, 70, 120]},
	]
	ACHIEVEMENTS = [
		{"id": "dist1", "name": "First Steps", "desc": "Run 1,000 m in total", "stat": "total_distance", "target": 1000, "reward": 50},
		{"id": "dist2", "name": "Dungeon Delver", "desc": "Run 10,000 m in total", "stat": "total_distance", "target": 10000, "reward": 150},
		{"id": "dist3", "name": "Abyss Walker", "desc": "Run 50,000 m in total", "stat": "total_distance", "target": 50000, "reward": 500},
		{"id": "cry1", "name": "Crystal Seeker", "desc": "Collect 200 crystals", "stat": "total_crystals", "target": 200, "reward": 50},
		{"id": "cry2", "name": "Crystal Hoarder", "desc": "Collect 2,000 crystals", "stat": "total_crystals", "target": 2000, "reward": 200},
		{"id": "cry3", "name": "Mana Lord", "desc": "Collect 10,000 crystals", "stat": "total_crystals", "target": 10000, "reward": 600},
		{"id": "run1", "name": "Rookie Hunter", "desc": "Finish 10 runs", "stat": "runs", "target": 10, "reward": 60},
		{"id": "run2", "name": "Veteran Hunter", "desc": "Finish 50 runs", "stat": "runs", "target": 50, "reward": 250},
		{"id": "best1", "name": "Sprinter", "desc": "Reach 1,500 m in one run", "stat": "best_distance", "target": 1500, "reward": 100},
		{"id": "best2", "name": "Marathon", "desc": "Reach 5,000 m in one run", "stat": "best_distance", "target": 5000, "reward": 300},
		{"id": "hun1", "name": "Guild Member", "desc": "Own 3 hunters", "stat": "hunters_owned", "target": 3, "reward": 150},
		{"id": "hun2", "name": "Full Roster", "desc": "Own all 5 hunters", "stat": "hunters_owned", "target": 5, "reward": 400},
		{"id": "pu1", "name": "Power Surge", "desc": "Collect 25 power-ups", "stat": "powerups_used", "target": 25, "reward": 80},
		{"id": "ab1", "name": "Awakened", "desc": "Use abilities 15 times", "stat": "abilities_used", "target": 15, "reward": 80},
	]
